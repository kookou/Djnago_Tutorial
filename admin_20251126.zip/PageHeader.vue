<template>
    <BRow>
        <BCol cols="12">
            <div
                class="page-title-box d-sm-flex align-items-center justify-content-between"
            >
                <!-- Title -->
                <h4 class="mb-sm-0">{{ title }}</h4>

                <!-- Breadcrumb (3depth) -->
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li v-if="grandParent" class="breadcrumb-item">
                            <BLink href="javascript:void(0);">
                                {{ grandParent }}
                            </BLink>
                        </li>

                        <li v-if="parent" class="breadcrumb-item">
                            <BLink href="javascript:void(0);">
                                {{ parent }}
                            </BLink>
                        </li>
                        <li class="breadcrumb-item active">{{ title }}</li>
                    </ol>
                </div>
            </div>
        </BCol>
    </BRow>
</template>

<script>
export default {
    props: {
        title: {
            type: String,
            default: ''
        },
        parent: {
            type: String,
            default: ''
        },
        grandParent: {
            type: String,
            default: ''
        }
    }
}
</script>
