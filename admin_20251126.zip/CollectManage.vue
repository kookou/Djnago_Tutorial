<template>
    <!-- 3depth 렌더링 -->
    <router-view />
</template>
