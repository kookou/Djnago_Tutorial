import { createWebHistory, createRouter } from 'vue-router'
import { SecurityStore } from '@/store/security'

/* -----------------------------------
 * 로그인 및 접근 권한 체크
 * ----------------------------------- */
const requireRoute = async (to, from, next) => {
    if (!to.path || ['/', '/logout'].includes(to.path)) return next()

    const securityStore = SecurityStore()

    if (!securityStore.getAuthorization) return next({ path: '/' })

    if (['/manual', '/brochure'].includes(to.path)) {
        window.open('https://test1.com/')
        return next(false)
    }

    return next()
}

/* -----------------------------------
 * Admin 메뉴 JSON
 * (라우터 + 서브사이드바를 동시에 생성하는 단일 소스)
 * ----------------------------------- */
export const adminMenu = [
    {
        label: '목적관리',
        route: '/admin/purpose',
        icon: 'ti ti-target',
        file: 'PurposeManage'
    },
    {
        label: '주제영역',
        route: '/admin/subject',
        icon: 'ti ti-category',
        file: 'SubjectManage'
    },
    {
        label: '메타관리',
        route: '/admin/meta',
        icon: 'ti ti-database',
        file: 'MetaManage'
    },
    {
        label: '관점관리',
        route: '/admin/view',
        icon: 'ti ti-eye',
        file: 'ViewManage'
    },

    {
        label: '수집관리',
        route: '/admin/collect',
        icon: 'ti ti-cloud-download',
        file: 'CollectManage',
        children: [
            {
                label: '일일 현황',
                route: '/admin/collect/daily',
                file: 'collect/CollectDaily'
            },
            {
                label: '주간 현황',
                route: '/admin/collect/weekly',
                file: 'collect/CollectWeekly'
            },
            {
                label: '기준정보 관리',
                route: '/admin/collect/master',
                file: 'collect/CollectMaster'
            }
        ]
    },

    {
        label: '워크리스트',
        route: '/admin/worklist',
        icon: 'ti ti-list-details',
        file: 'WorklistManage'
    },

    {
        label: '모니터링',
        route: '/admin/monitor',
        icon: 'ti ti-activity',
        file: 'MonitorManage',
        children: [
            {
                label: '실시간 모니터링',
                route: '/admin/monitor/realtime',
                file: 'monitor/MonitorRealtime'
            },
            {
                label: '정기수행 모니터링',
                route: '/admin/monitor/scheduled',
                file: 'monitor/MonitorScheduled'
            },
            {
                label: '시그널 모니터링',
                route: '/admin/monitor/signal',
                file: 'monitor/MonitorSignal'
            },
            {
                label: '통계',
                route: '/admin/monitor/stat',
                file: 'monitor/MonitorStat'
            },
            {
                label: '대시보드',
                route: '/admin/monitor/dashboard',
                file: 'monitor/MonitorDashboard'
            },
            {
                label: 'Job 이력조회',
                route: '/admin/monitor/job-history',
                file: 'monitor/MonitorJobHistory'
            },
            {
                label: 'Step 이력조회',
                route: '/admin/monitor/step-history',
                file: 'monitor/MonitorStepHistory'
            },
            {
                label: '배치 로그조회',
                route: '/admin/monitor/batch-log',
                file: 'monitor/MonitorBatchLog'
            }
        ]
    },

    {
        label: '기간중복관리',
        route: '/admin/period',
        icon: 'ti ti-calendar-cog',
        file: 'PeriodOverlapManage'
    },

    {
        label: '시스템관리',
        route: '/admin/system',
        icon: 'ti ti-settings',
        file: 'SystemMain',
        children: [
            {
                label: '공통코드',
                route: '/admin/system/common-code',
                file: 'system/CommonCode'
            },
            {
                label: '워크북/타겟팅',
                route: '/admin/system/workbook-target',
                file: 'system/WorkbookTargetManage'
            },
            {
                label: '테이블',
                route: '/admin/system/table',
                file: 'system/TableManage'
            },
            {
                label: '데이터 조회',
                route: '/admin/system/data-lookup',
                file: 'system/DataLookup'
            },
            {
                label: '공지사항',
                route: '/admin/system/notice',
                file: 'system/NoticeManage'
            },
            {
                label: '알림문자',
                route: '/admin/system/sms',
                file: 'system/SmsManage'
            },
            {
                label: '알림메일',
                route: '/admin/system/mail',
                file: 'system/MailManage'
            },
            {
                label: '운영자',
                route: '/admin/system/operator',
                file: 'system/OperatorManage'
            }
        ]
    }
]

/* -----------------------------------
 * JSON → 라우터 자동 변환
 * children 경로를 반드시 '상대경로'로 변환해야 3depth 정상 작동함
 * ----------------------------------- */
function buildAdminRoutes(menuList) {
    return menuList.map((menu) => {
        const route = {
            path: menu.route,
            name: menu.route.replace(/\//g, '_'),
            meta: {
                title: menu.label,
                authRequired: true,
                showSubSidebar: true,
                subSidebarMenu: adminMenu
            },
            beforeEnter: requireRoute,
            component: () => import(`@/views/admin/${menu.file}.vue`)
        }

        if (menu.children?.length) {
            route.children = menu.children.map((child) => {
                // 절대경로 → 상대경로 변환
                const childPath = child.route.startsWith(menu.route)
                    ? child.route.slice(menu.route.length + 1) // admin/collect/daily → daily
                    : child.route.replace(/^\//, '')

                return {
                    path: childPath,
                    name: child.route.replace(/\//g, '_'),
                    meta: {
                        title: child.label,
                        authRequired: true,
                        showSubSidebar: true,
                        subSidebarMenu: adminMenu
                    },
                    beforeEnter: requireRoute,
                    component: () => import(`@/views/admin/${child.file}.vue`)
                }
            })
        }

        return route
    })
}

/* -----------------------------------
 * 일반 라우트 + Admin 라우트 통합
 * ----------------------------------- */
const routes = [
    {
        path: '/',
        name: 'layouts',
        meta: { title: 'layouts', authRequired: true },
        beforeEnter: requireRoute,
        component: () => import('@/layouts/main.vue'),
        children: [
            {
                path: '',
                name: 'Home',
                beforeEnter: requireRoute,
                meta: { title: 'Home', authRequired: true },
                component: () => import('@/views/HomeMain.vue')
            },
            {
                path: 'expert/main',
                name: 'ExpertMain',
                beforeEnter: requireRoute,
                meta: { title: 'ExpertMain', authRequired: true },
                component: () => import('@/views/expert/ExpertMain.vue')
            },
            {
                path: 'worklist/main',
                name: 'WorklistMain',
                beforeEnter: requireRoute,
                meta: { title: 'WorklistMain', authRequired: true },
                component: () => import('@/views/worklist/WorklistMain.vue')
            },
            {
                path: 'campaign/list',
                name: 'CampaignList',
                beforeEnter: requireRoute,
                meta: { title: 'CampaignList', authRequired: true },
                component: () => import('@/views/campaign/CampaignList.vue')
            },
            {
                path: 'campaign/result',
                name: 'CampaignResult',
                beforeEnter: requireRoute,
                meta: { title: 'CampaignResult', authRequired: true },
                component: () => import('@/views/campaign/CampaignResult.vue')
            },

            // 🔥 자동 생성 Admin 모든 2depth/3depth
            ...buildAdminRoutes(adminMenu)
        ]
    }
]

/* -----------------------------------
 * Router 생성
 * ----------------------------------- */
const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes,
    scrollBehavior(to, from, savedPosition) {
        return savedPosition || { top: 0 }
    }
})

/* -----------------------------------
 * 전역 에러 코드 처리
 * ----------------------------------- */
router.beforeEach((to, from, next) => {
    const status = to.meta.statusCode
    if ([400, 401, 403, 404, 500].includes(status)) return next('/error')
    next()
})

export default router
