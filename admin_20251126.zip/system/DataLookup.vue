<template>
    <PageHeader title="데이터 조회" parent="시스템관리" grandParent="관리자" />
</template>

<script setup>
import PageHeader from '@/components/PageHeader'
</script>
