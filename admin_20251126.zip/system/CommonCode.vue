<template>
    <PageHeader
        title="공통코드 관리"
        parent="시스템관리"
        grandParent="관리자"
    />

    <div class="admin-wrapper common-code-wrapper">
        <!-- 좌측: 그룹코드 목록 -->
        <div class="admin-sidebar">
            <b-card
                header-class="admin-sidebar-header"
                footer-class="admin-sidebar-footer"
            >
                <template #header>
                    <h4 class="mb-0">그룹코드 목록</h4>
                    <b-button
                        variant="light-2"
                        @click="toggleAddGroup"
                        :disabled="isAddingGroup"
                        class="ms-auto"
                    >
                        <i class="ti ti-plus"></i> 신규 그룹코드
                    </b-button>
                </template>

                <div class="form-search-wrap w-auto mb-2 position-relative">
                    <input
                        type="text"
                        v-model="searchKeyword"
                        class="form-control"
                        placeholder="그룹코드명을 입력하세요"
                        autocomplete="off"
                    />
                    <b-button
                        variant="link"
                        class="btn-icon search-widget-icon"
                    >
                        <i class="ti ti-search"></i>
                    </b-button>
                </div>

                <Simplebar class="group-code-list">
                    <b-list-group flush class="list-group-numbered">
                        <b-list-group-item
                            tag="li"
                            v-for="(group, i) in filteredGroups"
                            :key="i"
                            class="list-group-item-action hstack"
                            :class="{ active: selectedGroup === group.code }"
                            @click="selectGroup(group)"
                        >
                            <span>{{ group.code }}</span>
                            <!-- 공통코드 개수 -->
                            <b-badge
                                variant="primary-subtle text-dark"
                                pill
                                class="ms-auto"
                                >{{ group.count }}</b-badge
                            >
                        </b-list-group-item>
                    </b-list-group>
                </Simplebar>

                <template #footer>
                    <div class="add-list-box" v-if="isAddingGroup">
                        <h4 class="mb-0">그룹코드 추가</h4>
                        <b-form-input
                            v-model="newGroupCode"
                            placeholder="그룹코드를 입력하세요"
                        />
                        <div class="btn-area">
                            <b-button variant="light" @click="cancelAddGroup"
                                >취소</b-button
                            >
                            <b-button variant="dark" @click="confirmAddGroup"
                                >저장</b-button
                            >
                        </div>
                    </div>
                </template>
            </b-card>
        </div>

        <!-- 우측: 공통코드 상세 -->
        <div class="admin-content">
            <b-card header-class="d-flex align-items-center">
                <template #header>
                    <h4 class="card-title mb-0">
                        <span
                            v-if="selectedGroup"
                            class="text-primary fw-semibold"
                        >
                            [{{ selectedGroup }}]
                            <span class="ms-1 text-dark">공통코드 목록</span>
                        </span>
                        <span v-else class="text-muted fw-normal">
                            <i class="ti ti-info-circle align-middle"></i>
                            선택된 그룹코드가 없습니다.
                        </span>
                    </h4>

                    <!-- 그룹 선택 시에만 버튼 표시 -->
                    <div v-if="selectedGroup" class="hstack gap-2 ms-auto">
                        <b-button variant="light-2" @click="addNewRow">
                            <i class="ti ti-plus"></i> 공통코드 추가
                        </b-button>
                        <div class="vr m-1"></div>
                        <b-button variant="soft-danger">
                            <i class="ti ti-trash"></i> 삭제
                        </b-button>
                        <b-button variant="soft-primary">
                            <i class="ti ti-device-floppy"></i> 저장
                        </b-button>
                        <b-button variant="light">
                            <i class="ti ti-x"></i> 취소
                        </b-button>
                    </div>
                </template>

                <b-row class="table-header">
                    <b-col sm="auto" class="status">
                        <h5>
                            전체 <span>{{ codeList.length }}</span> 건
                        </h5>
                    </b-col>
                </b-row>

                <!-- 공통코드 목록 테이블 -->
                <Simplebar class="common-code-list">
                    <table class="table table-sm align-middle text-center">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 25px">
                                    <b-form-checkbox
                                        class="form-check"
                                    ></b-form-checkbox>
                                </th>
                                <th>공통코드</th>
                                <th>공통코드명</th>
                                <th>공통코드값</th>
                                <th style="width: 70px">정렬순서</th>
                                <th>공통코드ID</th>
                                <th>등록일시</th>
                                <th>변경일시</th>
                                <th>생성자</th>
                                <th>수정자</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item, i) in pagedCodes" :key="i">
                                <td>
                                    <b-form-checkbox
                                        class="form-check"
                                        v-model="item.checked"
                                        :disabled="!item.editable"
                                    ></b-form-checkbox>
                                </td>
                                <td>
                                    <b-form-input
                                        v-model="item.code"
                                        @input="markEdited(item)"
                                    />
                                </td>
                                <td>
                                    <b-form-input
                                        v-model="item.name"
                                        @input="markEdited(item)"
                                    />
                                </td>
                                <td>
                                    <b-form-input
                                        v-model="item.value"
                                        @input="markEdited(item)"
                                    />
                                </td>
                                <td>
                                    <b-form-input
                                        v-model="item.sortOrder"
                                        type="number"
                                        @input="markEdited(item)"
                                        class="text-end"
                                    />
                                </td>
                                <td class="text-start">{{ item.id }}</td>
                                <td>{{ item.createdAt }}</td>
                                <td>{{ item.updatedAt }}</td>
                                <td>{{ item.creator }}</td>
                                <td>{{ item.modifier }}</td>
                            </tr>

                            <tr v-if="pagedCodes.length === 0">
                                <td
                                    colspan="10"
                                    class="text-center text-muted py-3"
                                >
                                    <EmptyMessage>
                                        선택된 그룹코드의 데이터가 없습니다.
                                    </EmptyMessage>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </Simplebar>

                <!-- 페이지네이션 -->
                <Pager
                    :page="page"
                    :total="totalPages"
                    @update:page="page = $event"
                />
            </b-card>
        </div>
    </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import PageHeader from '@/components/PageHeader'
import Simplebar from 'simplebar-vue'
import Pager from '@/components/Pager'
import EmptyMessage from '@/components/EmptyMessage.vue'

/* ------------------------------------
 * 그룹코드 목록
 * ------------------------------------ */
const groupCodes = ref([
    { code: 'SYS001', name: '시스템 설정', count: 0 },
    { code: 'USER001', name: '사용자 상태', count: 0 },
    { code: 'MAIL001', name: '메일 유형', count: 0 },
    { code: 'ALERT001', name: '알림 유형', count: 0 }
])

const searchKeyword = ref('')
const selectedGroup = ref(null)
const selectedGroupName = ref('')

/* 신규 그룹코드 추가 관련 상태 */
const isAddingGroup = ref(false)
const newGroupCode = ref('')

const toggleAddGroup = () => {
    isAddingGroup.value = !isAddingGroup.value
    newGroupCode.value = ''
}

/* 신규 그룹코드 등록 후 자동 선택 + 우측 초기화 */
const confirmAddGroup = () => {
    if (!newGroupCode.value.trim()) {
        alert('그룹코드를 입력해주세요.')
        return
    }

    const newGroup = { code: newGroupCode.value.trim() }

    groupCodes.value.push(newGroup)
    isAddingGroup.value = false

    // 자동 선택 및 공통코드 영역 초기화
    selectGroup(newGroup)
    codeList.value = []

    // alert 없이 즉시 공통코드 행 추가
    addNewRow()
}

const cancelAddGroup = () => {
    isAddingGroup.value = false
}

/* 그룹 검색 */
const filteredGroups = computed(() =>
    groupCodes.value.filter(
        (g) =>
            g.code.toLowerCase().includes(searchKeyword.value.toLowerCase()) ||
            g.name.includes(searchKeyword.value)
    )
)

/* ------------------------------------
 * 공통코드 목록
 * ------------------------------------ */
const codeList = ref([])
const page = ref(1)
const pageSize = 10
const totalPages = ref(1)

const pagedCodes = computed(() => {
    const start = (page.value - 1) * pageSize
    return codeList.value.slice(start, start + pageSize)
})

/* 그룹 선택 시 데이터 로드 (기존과 동일) */
const selectGroup = (group) => {
    selectedGroup.value = group.code
    selectedGroupName.value = group.name

    // 예시 데이터 생성
    codeList.value = Array.from({ length: 5 }, (_, i) => ({
        id: `${group.code}-${i + 1}`,
        code: `CODE${i + 1}`,
        name: `공통코드명 ${i + 1}`,
        value: `VALUE${i + 1}`,
        sortOrder: i + 1,
        createdAt: '2025-11-25',
        updatedAt: '2025-11-25',
        creator: 'admin',
        modifier: 'manager',
        checked: false,
        editable: true
    }))

    // 공통코드 개수 업데이트
    group.count = codeList.value.length
}

/* ------------------------------------
 * 행 편집 상태 처리
 * ------------------------------------ */
const markEdited = (item) => {
    if (!item.checked) item.checked = true
}

/* ------------------------------------
 * 새 행 추가
 * ------------------------------------ */
const addNewRow = () => {
    if (!selectedGroup.value) return alert('그룹코드를 먼저 선택하세요.')
    codeList.value.push({
        id: `${selectedGroup.value}-${Date.now()}`,
        code: '',
        name: '',
        value: '',
        sortOrder: codeList.value.length + 1,
        createdAt: new Date().toISOString().slice(0, 10),
        updatedAt: '',
        creator: 'admin',
        modifier: '',
        checked: true,
        editable: true
    })

    // count 동기화
    const target = groupCodes.value.find((g) => g.code === selectedGroup.value)
    if (target) target.count = codeList.value.length
}
</script>
