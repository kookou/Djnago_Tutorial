<template>
    <PageHeader
        title="알림메일 관리"
        parent="시스템관리"
        grandParent="관리자"
    />
</template>

<script setup>
import PageHeader from '@/components/PageHeader'
</script>
