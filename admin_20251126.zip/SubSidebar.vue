<template>
    <div class="app-menu sub-sidebar-menu" data-vertical-style="click">
        <Simplebar id="scrollbar" class="h-100" ref="scrollbar">
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title">
                    <span>관리자 메뉴</span>
                </li>

                <li v-for="(item, i) in menu" :key="i" class="nav-item">
                    <!-- 2depth : children이 있을 경우 -->
                    <BLink
                        v-if="item.children"
                        class="nav-link menu-link collapsed"
                        href="javascript:void(0);"
                        data-bs-toggle="collapse"
                        :data-bs-target="'#submenu-' + i"
                        role="button"
                        aria-expanded="false"
                        :aria-controls="'submenu-' + i"
                    >
                        <i :class="item.icon"></i>
                        <span>{{ item.label }}</span>
                    </BLink>

                    <!-- 3depth 영역 -->
                    <div
                        v-if="item.children"
                        class="collapse menu-dropdown"
                        :id="'submenu-' + i"
                    >
                        <ul class="nav nav-sm flex-column">
                            <li
                                v-for="(child, j) in item.children"
                                :key="j"
                                class="nav-item"
                            >
                                <router-link
                                    :to="child.route"
                                    class="nav-link"
                                    active-class="active"
                                >
                                    {{ child.label }}
                                </router-link>
                            </li>
                        </ul>
                    </div>

                    <!-- 2depth : children이 없는 경우 -->
                    <router-link
                        v-else
                        :to="item.route"
                        class="nav-link menu-link"
                        active-class="active"
                        @click.native="closeAllCollapses"
                    >
                        <i :class="item.icon"></i>
                        <span>{{ item.label }}</span>
                    </router-link>
                </li>
            </ul>
        </Simplebar>
    </div>
</template>

<script setup>
import { onMounted } from 'vue'
import Simplebar from 'simplebar-vue'
import Collapse from 'bootstrap/js/dist/collapse'

const props = defineProps({
    menu: { type: Array, default: () => [] }
})

// 열려 있는 collapse를 모두 닫는 함수
const closeAllCollapses = () => {
    const openCollapses = document.querySelectorAll('.collapse.show')
    openCollapses.forEach((el) => {
        const instance = Collapse.getInstance(el)
        if (instance) instance.hide()
    })
}

// collapse 기능 수동 초기화
onMounted(() => {
    const collapses = document.querySelectorAll('.collapse')
    collapses.forEach((el) => {
        if (!Collapse.getInstance(el)) {
            new Collapse(el, { toggle: false })
        }
    })
})
</script>
