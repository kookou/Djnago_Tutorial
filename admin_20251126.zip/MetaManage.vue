<template>
    <PageHeader title="메타관리" pageTitle="관리자" />
    <div class="admin-wrapper meta-wrapper">
        <div class="admin-content">
            <!-- 검색 영역 -->
            <section class="meta-search">
                <b-card>
                    <b-row class="gx-3 gy-2">
                        <b-col sm="auto" class="hstack gap-2">
                            <label class="col-form-label">활성 여부</label>
                            <b-form-select
                                v-model="search.active"
                                :options="activeOptions"
                            />
                        </b-col>

                        <b-col sm="auto" class="hstack gap-2">
                            <label class="col-form-label">테이블 타입</label>
                            <b-form-select
                                v-model="search.type"
                                :options="tableTypeOptions"
                            />
                        </b-col>

                        <b-col sm="auto" class="hstack gap-2">
                            <label class="col-form-label">테이블명</label>
                            <div class="form-search-wrap">
                                <input
                                    type="text"
                                    class="form-control"
                                    v-model="search.keyword"
                                    placeholder="찾으실 테이블명을 입력하세요"
                                    autocomplete="off"
                                    @keydown.enter.prevent="onDimensionSearch"
                                />
                                <b-button
                                    variant="link"
                                    class="btn-icon search-widget-icon"
                                    @click="onDimensionSearch"
                                >
                                    <i class="ti ti-search"></i>
                                </b-button>
                            </div>
                        </b-col>

                        <b-col sm="auto" class="hstack gap-2">
                            <label class="col-form-label">테이블 목록</label>
                            <b-form-select
                                v-model="search.tableId"
                                :options="tableList"
                            />
                        </b-col>

                        <b-col cols="auto">
                            <b-button variant="link" @click="refreshTables">
                                <i class="ti ti-refresh"></i> 새로고침
                            </b-button>
                        </b-col>
                    </b-row>
                </b-card>
            </section>

            <!-- 메타 테이블 정보 -->
            <section class="meta-info-wrap">
                <b-card>
                    <template #header>
                        <h4 class="card-title mb-0 text-primary">
                            ab_mapp_camp_tgt.txn
                        </h4>
                    </template>

                    <!-- 메타 테이블 기본 정보 -->
                    <div class="meta-info">
                        <h4>메타 테이블 정보</h4>
                        <b-row class="gy-2">
                            <b-col lg="9">
                                <div class="edit-box">
                                    <b-row class="gx-5 gy-2">
                                        <!-- 왼쪽 -->
                                        <b-col xl="6" class="vstack gap-2">
                                            <b-row>
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    메타 테이블 아이디
                                                </label>
                                                <b-col sm="8">
                                                    <b-form-input
                                                        v-model="meta.id"
                                                        readonly
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    메타 테이블 영문 이름
                                                </label>
                                                <b-col sm="8">
                                                    <b-form-input
                                                        v-model="meta.engName"
                                                        readonly
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    메타 테이블 한글 이름
                                                </label>
                                                <b-col sm="8">
                                                    <b-form-input
                                                        v-model="meta.korName"
                                                    />
                                                </b-col>
                                            </b-row>
                                        </b-col>

                                        <!-- 오른쪽 -->
                                        <b-col xl="6" class="vstack gap-2">
                                            <b-row>
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    파티션 키
                                                </label>
                                                <b-col sm="8">
                                                    <b-form-input
                                                        v-model="
                                                            meta.partitionKey
                                                        "
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row class="align-items-center">
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    메타 테이블 활성 상태
                                                </label>
                                                <b-col sm="8">
                                                    <b-form-checkbox
                                                        v-model="meta.active"
                                                        switch
                                                        class="mb-0"
                                                    >
                                                        {{
                                                            meta.active
                                                                ? '활성화'
                                                                : '비활성화'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    메타 테이블 소유자 타입
                                                </label>
                                                <b-col sm="8">
                                                    <b-form-select
                                                        v-model="meta.ownerType"
                                                        :options="
                                                            ownerTypeOptions
                                                        "
                                                        readonly
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-4 col-form-label"
                                                >
                                                    관심 생성요청
                                                </label>
                                                <b-col
                                                    sm="8"
                                                    class="hstack gap-2"
                                                >
                                                    <b-button
                                                        variant="light-2"
                                                        size="sm"
                                                        @click="
                                                            showViewRequestModal = true
                                                        "
                                                    >
                                                        관심 생성요청
                                                    </b-button>
                                                    <b-button
                                                        variant="light-2"
                                                        size="sm"
                                                        @click="
                                                            openViewResultModal
                                                        "
                                                    >
                                                        관심 생성결과
                                                    </b-button>
                                                </b-col>
                                            </b-row>
                                        </b-col>
                                    </b-row>
                                </div>
                            </b-col>

                            <!-- 오른쪽 메타 정보 -->
                            <b-col lg="3" class="edit-info">
                                <b-list-group tag="ul" flush>
                                    <b-list-group-item tag="li">
                                        <label>등록일시</label>
                                        <strong>{{ meta.createdAt }}</strong>
                                    </b-list-group-item>
                                    <b-list-group-item tag="li">
                                        <label>변경일시</label>
                                        <strong>{{ meta.updatedAt }}</strong>
                                    </b-list-group-item>
                                    <b-list-group-item tag="li">
                                        <label>생성자 ID</label>
                                        <strong>{{ meta.createdBy }}</strong>
                                    </b-list-group-item>
                                    <b-list-group-item tag="li">
                                        <label>수정자 ID</label>
                                        <strong>{{ meta.updatedBy }}</strong>
                                    </b-list-group-item>
                                </b-list-group>

                                <!-- Alert: 테이블 수정 알림 -->
                                <b-alert
                                    :show="metaEdited"
                                    variant="warning"
                                    class="alert-additional shadow mb-0 position-absolute"
                                    style="bottom: 50px; right: 12px"
                                >
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <i
                                                class="ti ti-alert-triangle fs-18 align-middle"
                                            ></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h5 class="alert-heading mb-1">
                                                테이블 항목의 수정사항이
                                                있습니다!
                                            </h5>
                                            <p class="mb-0 small">
                                                변경 내용을 저장하려면
                                                <strong>‘저장’</strong>
                                                버튼을 눌러주세요.
                                            </p>
                                        </div>
                                    </div>
                                </b-alert>

                                <div class="btn-area">
                                    <b-button
                                        variant="light-2"
                                        @click="showCloneModal = true"
                                    >
                                        <i class="ti ti-copy"></i>테이블 복제
                                    </b-button>
                                    <div class="hstack gap-2">
                                        <b-button
                                            variant="light"
                                            @click="cancelEdit"
                                        >
                                            취소
                                        </b-button>
                                        <b-button
                                            variant="dark"
                                            @click="saveMeta"
                                        >
                                            저장
                                        </b-button>
                                    </div>
                                </div>
                            </b-col>
                        </b-row>
                    </div>

                    <!-- 테이블 내 필드 정보 -->
                    <div class="meta-fields">
                        <h4>테이블 내 필드</h4>
                        <b-row>
                            <!-- 왼쪽: 필드명 검색/트리 -->
                            <b-col xl="4" class="field-tree">
                                <Simplebar>
                                    필드명 검색 + 트리 컴포넌트 자리
                                </Simplebar>
                                <div class="field-tree-footer">
                                    <b-button
                                        variant="light-2"
                                        @click="showAddModal = true"
                                    >
                                        <i class="ti ti-plus"></i> 새 필드 추가
                                    </b-button>
                                    <b-button
                                        variant="light-2"
                                        @click="showBulkModal = true"
                                    >
                                        <i class="ti ti-edit"></i> 필드 속성
                                        일괄변경
                                    </b-button>
                                </div>
                            </b-col>

                            <!-- 오른쪽: 필드 속성 및 상세 -->
                            <b-col xl="8">
                                <div class="edit-box">
                                    <b-row class="gx-5 gy-2">
                                        <!-- 왼쪽 -->
                                        <b-col xl="6" class="vstack gap-2">
                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 아이디</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="field.id"
                                                        readonly
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 활성 여부</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="field.active"
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.active
                                                                ? '활성화'
                                                                : '비활성화'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 데이터타입</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="field.dataType"
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 이름</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="field.name"
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 마스크
                                                    여부</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="field.masked"
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.masked
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 마스크
                                                    타입</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="field.maskType"
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >정보 보안 여부</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="field.secured"
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.secured
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >관점 여부</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="field.viewYn"
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.viewYn
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >BIDW 관점 여부</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="
                                                            field.bidwViewYn
                                                        "
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.bidwViewYn
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >관점 최근 업데이트</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="
                                                            field.viewUpdatedAt
                                                        "
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>
                                        </b-col>

                                        <!-- 오른쪽 -->
                                        <b-col xl="6" class="vstack gap-2">
                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >메타 필드 정보</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="field.desc"
                                                        rows="2"
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >이미지 업로드</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-file
                                                        v-model="field.image"
                                                        accept="image/*"
                                                        browse-text="이미지 선택"
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >Expert 모드 필수</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="
                                                            field.expertRequired
                                                        "
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.expertRequired
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >Easy 모드 조건</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="
                                                            field.easyCondition
                                                        "
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.easyCondition
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >Easy 모드 출력</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-checkbox
                                                        v-model="
                                                            field.easyOutput
                                                        "
                                                        switch
                                                        inline
                                                    >
                                                        {{
                                                            field.easyOutput
                                                                ? 'Yes'
                                                                : 'No'
                                                        }}
                                                    </b-form-checkbox>
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >Easy 모드 분류</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="
                                                            field.easyCategory
                                                        "
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >등록 일시</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="
                                                            field.createdAt
                                                        "
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >변경 일시</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="
                                                            field.updatedAt
                                                        "
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >생성자 아이디</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="
                                                            field.createdBy
                                                        "
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>

                                            <b-row>
                                                <label
                                                    class="col-sm-5 col-form-label"
                                                    >수정자 아이디</label
                                                >
                                                <b-col sm="7">
                                                    <b-form-input
                                                        v-model="
                                                            field.updatedBy
                                                        "
                                                        disabled
                                                    />
                                                </b-col>
                                            </b-row>
                                        </b-col>
                                    </b-row>
                                </div>

                                <div class="btn-area">
                                    <!-- Alert: 필드 수정 알림 -->
                                    <b-alert
                                        :show="fieldEdited"
                                        variant="warning"
                                        class="alert-additional shadow mb-0 position-absolute"
                                        style="bottom: 0; right: 124px"
                                    >
                                        <div class="d-flex">
                                            <div class="flex-shrink-0 me-3">
                                                <i
                                                    class="ti ti-alert-triangle fs-18 align-middle"
                                                ></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h5 class="alert-heading mb-1">
                                                    필드항목의 수정사항이
                                                    있습니다!
                                                </h5>
                                                <p class="mb-0 small">
                                                    변경 내용을 저장하려면
                                                    <strong>‘저장’</strong>
                                                    버튼을 눌러주세요.
                                                </p>
                                            </div>
                                        </div>
                                    </b-alert>
                                    <b-button
                                        variant="light"
                                        @click="cancelField"
                                        >취소</b-button
                                    >
                                    <b-button variant="dark" @click="saveField"
                                        >저장</b-button
                                    >
                                </div>
                            </b-col>
                        </b-row>
                    </div>
                </b-card>
            </section>
        </div>
    </div>

    <!-- Modal: 관점 생성요청 -->
    <ViewRequestModal
        v-model="showViewRequestModal"
        :items="metaFields"
        @save="handleViewRequestSave"
    />

    <!-- Modal: 관점 생성결과 -->
    <ViewResultModal v-model="showViewResultModal" />

    <!-- Modal: 테이블 복제 -->
    <TableCloneModal
        v-model="showCloneModal"
        :table="meta"
        @clone="handleCloneTable"
    />

    <!-- Modal: 새 필드 추가 -->
    <AddFieldModal v-model="showAddModal" @save="handleAddField" />

    <!-- Modal: 필드 속성 일괄 변경 -->
    <BulkFieldEditModal
        v-model="showBulkModal"
        :items="fieldList"
        @save="handleBulkSave"
    />
</template>

<script setup>
import { ref, watch } from 'vue'
import PageHeader from '@/components/PageHeader'
import Simplebar from 'simplebar-vue'

const metaEdited = ref(false)
const fieldEdited = ref(false)

import ViewRequestModal from '@/components/admin/ViewRequestModal.vue'
import ViewResultModal from '@/components/admin/ViewResultModal.vue'
import TableCloneModal from '@/components/admin/TableCloneModal.vue'
import AddFieldModal from '@/components/admin/AddFieldModal.vue'
import BulkFieldEditModal from '@/components/admin/BulkFieldEditModal.vue'

const showViewResultModal = ref(false)
const showViewRequestModal = ref(false)
const showCloneModal = ref(false)
const showAddModal = ref(false)
const showBulkModal = ref(false)
const search = ref({
    active: 'all',
    type: 'all',
    keyword: '',
    tableId: ''
})

const activeOptions = [
    { value: 'all', text: '전체' },
    { value: 'active', text: '활성화' },
    { value: 'inactive', text: '비활성화' }
]

const tableTypeOptions = [
    { value: 'all', text: '전체' },
    { value: 'MT', text: '일반테이블(MT)' },
    { value: 'VT', text: '복제테이블(VT)' }
]

const tableList = [
    { value: '', text: '테이블을 선택하세요' },
    { value: 'MT000000002708', text: 'ab_mapp_camp_tgt.txn' }
]

const meta = ref({
    id: 'MT000000002708',
    engName: 'ab_mapp_camp_tgt.txn',
    korName: '캠페인 타겟 테이블',
    partitionKey: 'campaign_id',
    active: true,
    ownerType: 'all',
    createdAt: '2025-01-10',
    updatedAt: '2025-02-03',
    createdBy: 'admin',
    updatedBy: 'marketer'
})

const ownerTypeOptions = [
    { value: 'all', text: '전체' },
    { value: 'internal', text: '내부' },
    { value: 'external', text: '외부' }
]

const field = ref({
    id: 'FLD001',
    active: true,
    dataType: 'STRING',
    name: 'customer_name',
    maskType: '',
    desc: '',
    image: null
})

const metaFields = ref([
    { name: 'customer_name', todayRequest: true, scheduleDay: 3 },
    { name: 'customer_id', todayRequest: false, scheduleDay: 10 },
    { name: 'purchase_count', todayRequest: true, scheduleDay: 15 }
])

const fieldList = ref([
    { name: 'customer_name', active: true },
    { name: 'customer_id', active: false },
    { name: 'age', active: true }
])

function handleViewRequestSave(updated) {
    metaFields.value = updated
    console.log('관심 생성요청 저장됨:', updated)
    alert('관점 생성요청 설정이 저장되었습니다.')
}

function handleCloneTable(cloned) {
    console.log('복제된 테이블:', cloned)
    alert(`복제테이블이 생성되었습니다.\nID: ${cloned.id}`)
}

function handleAddField(newField) {
    fieldList.value.push({
        no: fieldList.value.length + 1,
        name: newField.name,
        active: true
    })
    alert(`새 필드가 추가되었습니다: ${newField.korName} (${newField.name})`)
}

function handleBulkSave(updated) {
    fieldList.value = updated
    alert('필드 속성 일괄 변경이 저장되었습니다.')
}

function refreshTables() {
    console.log('테이블 목록 새로고침')
}

function openViewResultModal() {
    console.log('결과 버튼 클릭됨', showViewResultModal.value)
    showViewResultModal.value = true
    console.log('변경 후:', showViewResultModal.value)
}

// ✅ 저장 / 취소 시 알림 사라짐
function saveMeta() {
    metaEdited.value = false
}
function cancelEdit() {
    metaEdited.value = false
}
function saveField() {
    fieldEdited.value = false
}
function cancelField() {
    fieldEdited.value = false
}

// ✅ 변경 감지
watch(
    () => ({
        korName: meta.value.korName,
        partitionKey: meta.value.partitionKey,
        active: meta.value.active
    }),
    (newVal, oldVal) => {
        if (JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
            metaEdited.value = true
        }
    },
    { deep: true }
)

watch(
    () => ({
        desc: field.value.desc,
        maskType: field.value.maskType,
        active: field.value.active, // 활성 여부
        secured: field.value.secured, // 정보보안 여부
        viewYn: field.value.viewYn, // 관점 여부
        bidwViewYn: field.value.bidwViewYn, // BIDW 여부
        expertRequired: field.value.expertRequired,
        easyCondition: field.value.easyCondition,
        easyOutput: field.value.easyOutput,
        easyCategory: field.value.easyCategory
    }),
    (newVal, oldVal) => {
        if (JSON.stringify(newVal) !== JSON.stringify(oldVal)) {
            fieldEdited.value = true
        }
    },
    { deep: true }
)
</script>
