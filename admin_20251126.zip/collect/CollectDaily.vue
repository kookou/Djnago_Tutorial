<template>
    <PageHeader title="일일 현황" parent="수집관리" grandParent="관리자" />
</template>

<script setup>
import PageHeader from '@/components/PageHeader'
</script>
