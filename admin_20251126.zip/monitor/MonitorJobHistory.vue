<template>
    <PageHeader title="Job 이력조회" parent="모니터링" grandParent="관리자" />
</template>

<script setup>
import PageHeader from '@/components/PageHeader'
</script>
