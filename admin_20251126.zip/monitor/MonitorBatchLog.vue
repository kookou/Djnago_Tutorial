<template>
    <PageHeader title="배치 로그 조회" parent="모니터링" grandParent="관리자" />
</template>

<script setup>
import PageHeader from '@/components/PageHeader'
</script>
