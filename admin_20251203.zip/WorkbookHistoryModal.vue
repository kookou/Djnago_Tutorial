<template>
    <b-modal
        v-model="modelValue"
        title="타겟팅 작업이력"
        size="lg"
        centered
        hide-footer
    >
        <div v-if="loading" class="text-center py-4">
            <b-spinner></b-spinner>
        </div>

        <div v-else>
            <ul class="list-group list-group-flush">
                <li
                    v-for="(log, i) in logs"
                    :key="i"
                    class="list-group-item d-flex justify-content-between"
                >
                    <span>
                        <b>{{ log.action }}</b>
                        <span class="text-muted ms-2">{{ log.user }}</span>
                    </span>
                    <span>{{ log.date }}</span>
                </li>

                <li
                    v-if="logs.length === 0"
                    class="list-group-item text-center text-muted"
                >
                    이력이 없습니다.
                </li>
            </ul>
        </div>
    </b-modal>
</template>

<script setup>
import { ref, watch } from 'vue'
const props = defineProps({
    modelValue: Boolean,
    targetId: String
})
const emit = defineEmits(['update:modelValue'])

const logs = ref([])
const loading = ref(false)

watch(
    () => props.modelValue,
    (val) => {
        if (val) loadHistory()
    }
)

const loadHistory = () => {
    loading.value = true
    logs.value = []

    setTimeout(() => {
        // 실제 API 호출 자리 (mock)
        logs.value = [
            { action: '타겟팅 생성', user: 'admin', date: '2025-01-01' },
            { action: '타겟팅명 변경', user: 'manager', date: '2025-01-05' },
            { action: '타겟팅 실행', user: 'admin', date: '2025-01-10' }
        ]
        loading.value = false
    }, 600)
}
</script>
