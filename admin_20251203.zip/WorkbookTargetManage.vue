<template>
    <PageHeader
        title="워크북 / 타겟팅 조회"
        parent="타겟팅 관리"
        grandParent="관리자"
    />

    <div class="admin-wrapper workbook-target-admin d-flex">
        <!--  1. 워크북 목록  -->
        <div class="admin-sidebar workbook-sidebar">
            <b-card
                header-class="admin-sidebar-header"
                footer-class="admin-sidebar-footer"
            >
                <!-- 헤더 -->
                <template #header>
                    <div
                        class="d-flex justify-content-between align-items-center"
                    >
                        <h5 class="mb-0">
                            워크북 목록
                            <span class="text-primary"
                                >({{ workbookList.length }})</span
                            >
                        </h5>
                    </div>

                    <!-- 검색 -->
                    <div class="form-search-wrap mt-2 position-relative">
                        <input
                            type="text"
                            v-model="searchWorkbook"
                            class="form-control"
                            placeholder="워크북명 검색"
                        />
                        <b-button
                            variant="link"
                            class="btn-icon search-widget-icon"
                        >
                            <i class="ti ti-search"></i>
                        </b-button>
                    </div>
                </template>

                <!-- 바디 -->
                <Simplebar
                    :style="{ maxHeight: leftHeight + 'px' }"
                    class="workbook-list"
                >
                    <ul class="list-group list-group-flush">
                        <li
                            v-for="wb in filteredWorkbooks"
                            :key="wb.id"
                            class="list-group-item hstack gap-2 cursor-pointer"
                            :class="{ active: selectedWorkbookId === wb.id }"
                            @click="selectWorkbook(wb)"
                        >
                            <i class="ti ti-folder text-primary fs-18"></i>
                            <span class="flex-grow-1">{{ wb.name }}</span>
                            <b-badge pill variant="light">{{
                                wb.count
                            }}</b-badge>
                        </li>

                        <li
                            v-if="filteredWorkbooks.length === 0"
                            class="list-group-item text-center text-muted"
                        >
                            워크북이 없습니다.
                        </li>
                    </ul>
                </Simplebar>

                <!-- 푸터 -->
                <template #footer>
                    <b-button block variant="dark" @click="addWorkbook">
                        <i class="ti ti-plus"></i> 새 워크북 추가
                    </b-button>
                </template>
            </b-card>
        </div>

        <!--  2. 타겟팅 목록  -->
        <div class="admin-middle target-sidebar">
            <b-card header-class="admin-sidebar-header">
                <!-- 헤더 -->
                <template #header>
                    <div
                        class="d-flex justify-content-between align-items-center"
                    >
                        <h5 class="mb-0">
                            타겟팅 목록
                            <span class="text-primary"
                                >({{ targetListForWorkbook.length }})</span
                            >
                        </h5>
                    </div>

                    <div class="form-search-wrap mt-2 position-relative">
                        <input
                            type="text"
                            v-model="searchTarget"
                            class="form-control"
                            placeholder="타겟팅명 검색"
                        />
                        <b-button
                            variant="link"
                            class="btn-icon search-widget-icon"
                        >
                            <i class="ti ti-search"></i>
                        </b-button>
                    </div>
                </template>

                <!-- 바디 -->
                <Simplebar
                    :style="{ maxHeight: middleHeight + 'px' }"
                    class="target-list"
                >
                    <ul class="list-group list-group-flush">
                        <li
                            v-for="t in filteredTargets"
                            :key="t.id"
                            class="list-group-item hstack gap-2 align-items-center cursor-pointer"
                            :class="{ active: selectedTargetId === t.id }"
                            @click="selectTarget(t)"
                        >
                            <b-form-checkbox
                                v-model="checkedTargets"
                                :value="t.id"
                            />

                            <div class="flex-grow-1">
                                <b-badge
                                    v-if="t.deleteRequested"
                                    variant="danger"
                                    class="me-1"
                                    >삭제요청</b-badge
                                >

                                {{ t.name }}
                            </div>

                            <b-button
                                variant="ghost-light"
                                size="sm"
                                class="btn-icon"
                                @click.stop="copyTarget(t)"
                            >
                                <i class="ti ti-copy"></i>
                            </b-button>

                            <b-button
                                variant="ghost-light"
                                size="sm"
                                class="btn-icon"
                                @click.stop="deleteTarget(t)"
                            >
                                <i class="ti ti-trash"></i>
                            </b-button>
                        </li>

                        <li
                            v-if="filteredTargets.length === 0"
                            class="list-group-item text-center text-muted"
                        >
                            타겟팅이 없습니다.
                        </li>
                    </ul>
                </Simplebar>
            </b-card>
        </div>

        <!--  3. 상세 정보 (워크북/타겟팅)  -->
        <div class="admin-content workbook-target-detail">
            <b-card>
                <!-- 헤더 -->
                <template #header>
                    <h4 class="card-title mb-0">
                        <template v-if="detailType === 'workbook'">
                            워크북 상세정보
                        </template>

                        <template v-else-if="detailType === 'target'">
                            타겟팅 상세정보
                            <b-button
                                size="sm"
                                variant="light"
                                class="ms-2"
                                @click="openHistory"
                            >
                                <i class="ti ti-history"></i> 작업이력
                            </b-button>
                        </template>

                        <template v-else>
                            <span class="text-muted"
                                >상세 정보를 선택하세요</span
                            >
                        </template>
                    </h4>
                </template>

                <!-- 상세 영역 -->
                <Simplebar :style="{ height: rightHeight + 'px' }">
                    <!-- 워크북 상세 -->
                    <div v-if="detailType === 'workbook'">
                        <DetailRow label="워크북 ID" :value="detail.wbId" />
                        <DetailRow label="워크북 오너" :value="detail.owner" />
                        <DetailRow
                            label="워크북명"
                            :value="detail.wbName"
                            editable
                            @edit="editField('wbName')"
                        />
                        <DetailRow label="등록일시" :value="detail.createdAt" />
                        <DetailRow
                            label="워크북 타입"
                            :value="detail.wbType"
                            editable
                            @edit="editField('wbType')"
                        />
                        <DetailRow label="변경일시" :value="detail.updatedAt" />
                        <DetailRow
                            label="워크북 상태"
                            :value="detail.wbStatus"
                            editable
                            @edit="editField('wbStatus')"
                        />
                        <DetailRow
                            label="생성자 ID"
                            :value="detail.creatorId"
                        />
                        <DetailRow
                            label="워크북 오더"
                            :value="detail.order"
                            editable
                            @edit="editField('order')"
                        />
                        <DetailRow
                            label="수정자 ID"
                            :value="detail.modifierId"
                        />
                    </div>

                    <!-- 타겟팅 상세 -->
                    <div v-if="detailType === 'target'">
                        <DetailRow label="타겟팅 ID" :value="detail.tgId" />
                        <DetailRow
                            label="타겟팅 목적"
                            :value="detail.purpose"
                        />
                        <DetailRow
                            label="타겟팅명"
                            :value="detail.tgName"
                            editable
                            @edit="editField('tgName')"
                        />
                        <DetailRow label="주제영역" :value="detail.subject" />
                        <DetailRow
                            label="타겟팅 타입"
                            :value="detail.tgType"
                            editable
                            @edit="editField('tgType')"
                        />
                        <DetailRow
                            label="등록 일시"
                            :value="detail.createdAt"
                        />
                        <DetailRow
                            label="제한건수"
                            :value="detail.limit"
                            editable
                            @edit="editField('limit')"
                        />
                        <DetailRow label="변경일시" :value="detail.updatedAt" />
                        <DetailRow
                            label="삭제 요청일"
                            :value="detail.deleteDate"
                            editable
                            @edit="editField('deleteDate')"
                        />
                        <DetailRow
                            label="생성자 ID"
                            :value="detail.creatorId"
                        />
                        <DetailRow
                            label="워크북 ID"
                            :value="detail.wbId"
                            editable
                            @edit="editField('wbId')"
                        />
                        <DetailRow
                            label="수정자 ID"
                            :value="detail.modifierId"
                        />
                    </div>
                </Simplebar>
            </b-card>
        </div>
    </div>

    <!-- 작업이력 모달 -->
    <WorkbookHistoryModal v-model="historyVisible" :target-id="detail?.tgId" />
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import Simplebar from 'simplebar-vue'
import Swal from 'sweetalert2'
import PageHeader from '@/components/PageHeader.vue'
import DetailRow from '@/components/DetailRow.vue'
import WorkbookHistoryModal from '@/components/admin/WorkbookHistoryModal.vue'

/* -------------------------------------------------
   더미 워크북 데이터
------------------------------------------------- */
const workbookList = ref([
    { id: 'WB001', name: '광고 캠페인', count: 2, owner: '91313045' },
    { id: 'WB002', name: 'VIP 분석', count: 3, owner: '91313045' }
])

/* -------------------------------------------------
   타겟팅 데이터 (워크북별)
------------------------------------------------- */
const targetList = ref([
    { id: 'TGT1001', wbId: 'WB001', name: 'VIP 추출', deleteRequested: false },
    {
        id: 'TGT1002',
        wbId: 'WB001',
        name: '신규 고객 군',
        deleteRequested: true
    },
    {
        id: 'TGT2001',
        wbId: 'WB002',
        name: '이탈예정 고객',
        deleteRequested: false
    }
])

/* -------------------------------------------------
   검색 및 필터
------------------------------------------------- */
const searchWorkbook = ref('')
const searchTarget = ref('')

const filteredWorkbooks = computed(() =>
    workbookList.value.filter((w) =>
        w.name.toLowerCase().includes(searchWorkbook.value.toLowerCase())
    )
)

const selectedWorkbookId = ref(null)

const targetListForWorkbook = computed(() =>
    targetList.value.filter((t) => t.wbId === selectedWorkbookId.value)
)

const filteredTargets = computed(() =>
    targetListForWorkbook.value.filter((t) =>
        t.name.toLowerCase().includes(searchTarget.value.toLowerCase())
    )
)

/* -------------------------------------------------
   상세정보
------------------------------------------------- */
const detail = ref({})
const detailType = ref('') // "workbook" | "target"

/* -------------------------------------------------
   워크북 선택
------------------------------------------------- */
const selectWorkbook = (w) => {
    selectedWorkbookId.value = w.id
    selectedTargetId.value = null
    detailType.value = 'workbook'

    detail.value = {
        wbId: w.id,
        wbName: w.name,
        owner: w.owner,
        wbType: '일반',
        wbStatus: '정상',
        order: 1,
        createdAt: '2025-01-01',
        updatedAt: '2025-01-05',
        creatorId: 'admin',
        modifierId: 'manager'
    }
}

/* -------------------------------------------------
   타겟팅 선택
------------------------------------------------- */
const selectedTargetId = ref(null)

const selectTarget = (t) => {
    selectedTargetId.value = t.id
    detailType.value = 'target'

    detail.value = {
        tgId: t.id,
        tgName: t.name,
        wbId: t.wbId,
        purpose: '캠페인 대상 선정',
        tgType: '세그먼트',
        subject: '고객 분석',
        limit: 10000,
        createdAt: '2025-01-01',
        updatedAt: '2025-01-05',
        deleteDate: t.deleteRequested ? '2025-01-03' : '',
        creatorId: 'admin',
        modifierId: 'manager'
    }
}

/* -------------------------------------------------
   타겟팅 복사
------------------------------------------------- */
const copyTarget = (t) => {
    const newId = 'TGT' + Date.now()

    targetList.value.push({
        ...t,
        id: newId,
        name: t.name + ' (복사)',
        deleteRequested: false
    })

    selectedTargetId.value = newId
}

/* -------------------------------------------------
   타겟팅 삭제
------------------------------------------------- */
const deleteTarget = (t) => {
    Swal.fire({
        title: '삭제하시겠습니까?',
        html: `<b>${t.name}</b> 타겟팅은 되돌릴 수 없습니다.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f1416c',
        confirmButtonText: '삭제',
        cancelButtonText: '취소'
    }).then((res) => {
        if (res.isConfirmed) {
            targetList.value = targetList.value.filter((v) => v.id !== t.id)

            if (selectedTargetId.value === t.id) {
                selectedTargetId.value = null
                detailType.value = ''
            }
        }
    })
}

/* -------------------------------------------------
   작업이력 모달
------------------------------------------------- */
const historyVisible = ref(false)
const openHistory = () => {
    if (!detail.value?.tgId) return
    historyVisible.value = true
}

/* -------------------------------------------------
   높이 계산
------------------------------------------------- */
const leftHeight = ref(400)
const middleHeight = ref(400)
const rightHeight = ref(500)

onMounted(() => {
    const calcHeight = () => {
        const offset = 160
        leftHeight.value = window.innerHeight - offset
        middleHeight.value = window.innerHeight - offset
        rightHeight.value = window.innerHeight - offset - 40
    }
    calcHeight()
    window.addEventListener('resize', calcHeight)
})
</script>
