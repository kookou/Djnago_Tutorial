<template>
    <PageHeader title="목적관리" pageTitle="관리자" />
    <div class="admin-wrapper target-purpose-wrap">
        <!-- 타겟팅 목적 목록 -->
        <div class="admin-sidebar target-purpose-list">
            <b-card
                :footer-class="[
                    'admin-sidebar-footer',
                    { 'add-open': addOpen }
                ]"
            >
                <template #header>
                    <div
                        class="d-flex justify-content-between align-items-center"
                    >
                        <h4 class="mb-0">타겟팅 목적 목록</h4>
                    </div>
                </template>

                <Simplebar :style="{ height: leftHeight + 'px' }">
                    <!-- draggable 리스트 -->
                    <draggable
                        v-model="purposes"
                        item-key="id"
                        animation="150"
                        class="draggable-container"
                    >
                        <template #item="{ element }">
                            <b-card
                                :class="{
                                    active: selectedPurpose?.id === element.id
                                }"
                                @click="selectPurpose(element)"
                            >
                                <div class="draggable-item">
                                    <div class="label">
                                        {{ element.title }}
                                    </div>
                                    <b-badge
                                        :variant="
                                            element.active
                                                ? 'info-subtle'
                                                : 'light'
                                        "
                                    >
                                        {{ element.active ? '사용' : '미사용' }}
                                    </b-badge>
                                    <i
                                        class="ti ti-grip-vertical text-muted"
                                    ></i>
                                </div>
                            </b-card>
                        </template>
                    </draggable>
                </Simplebar>

                <template #footer>
                    <!-- ▼ 추가 버튼 (폼 열리면 숨김) -->
                    <b-button
                        v-if="addButtonVisible"
                        variant="link"
                        size="lg"
                        class="add-btn"
                        @click="openAddBox"
                    >
                        <i class="ti ti-plus"></i> 타겟팅 목적 추가
                    </b-button>

                    <!-- ▼ 아래에서 올라오는 추가 입력 폼 -->
                    <transition
                        @before-enter="hBeforeEnter"
                        @enter="hEnter"
                        @before-leave="hBeforeLeave"
                        @leave="hLeave"
                        @after-leave="onAddBoxClosed"
                    >
                        <div v-if="addOpen" class="add-list-box">
                            <!-- ▼ 아래에서 위로 부드럽게 올라오는 입력 폼 -->
                            <h5 class="text-primary">타겟팅 목적 추가</h5>

                            <b-row class="row-cols-1 g-2">
                                <b-col class="hstack gap-2">
                                    <label class="col-form-label col-2"
                                        >목적명</label
                                    >
                                    <b-form-input v-model="newPurpose.title" />
                                </b-col>
                                <b-col class="hstack gap-2">
                                    <label class="col-form-label col-2"
                                        >설명</label
                                    >
                                    <b-form-textarea
                                        rows="2"
                                        v-model="newPurpose.desc"
                                    />
                                </b-col>
                            </b-row>

                            <div class="btn-area">
                                <b-button variant="light" @click="cancelAdd"
                                    >취소</b-button
                                >
                                <b-button variant="dark" @click="addPurpose"
                                    >저장</b-button
                                >
                            </div>
                        </div>
                    </transition>
                </template>
            </b-card>
        </div>

        <!-- 오른쪽: 상세 내용 -->
        <div class="admin-content">
            <b-card v-if="selectedPurpose" class="target-purpose">
                <template #header>
                    <h3 class="mt-2 mb-n2">{{ selectedPurpose.title }}</h3>
                </template>
                <Simplebar :style="{ height: rightHeight + 'px' }">
                    <!-- 타겟팅 목적 정보 -->
                    <section class="target-purpose-info">
                        <h4>타겟팅 목적 정보</h4>
                        <div class="d-flex gap-4">
                            <b-col md="8">
                                <div class="edit-box">
                                    <b-row>
                                        <label class="col-sm-4 col-form-label"
                                            >타겟팅 목적 ID</label
                                        >
                                        <b-col>
                                            <b-form-input
                                                :value="selectedPurpose.id"
                                                disabled
                                            />
                                        </b-col>
                                    </b-row>
                                    <b-row>
                                        <label class="col-sm-4 col-form-label"
                                            >타겟팅 목적명</label
                                        >
                                        <b-col>
                                            <b-form-input
                                                v-model="selectedPurpose.title"
                                            />
                                        </b-col>
                                    </b-row>
                                    <b-row>
                                        <label class="col-sm-4 col-form-label"
                                            >타겟팅 목적 설명</label
                                        >
                                        <b-col>
                                            <b-form-textarea
                                                v-model="selectedPurpose.desc"
                                                rows="3"
                                            />
                                        </b-col>
                                    </b-row>
                                    <b-row class="align-items-center">
                                        <label
                                            class="col-sm-4 col-form-label py-0"
                                            >사용 여부</label
                                        >
                                        <b-col>
                                            <b-form-checkbox
                                                v-model="selectedPurpose.active"
                                                switch
                                                inline
                                                class="mb-0"
                                            >
                                                {{
                                                    selectedPurpose.active
                                                        ? '사용'
                                                        : '미사용'
                                                }}
                                            </b-form-checkbox>
                                        </b-col>
                                    </b-row>
                                </div>
                            </b-col>

                            <b-col cols="auto" class="edit-info">
                                <b-list-group tag="ul" flush>
                                    <b-list-group-item tag="li">
                                        <label>등록일시</label>
                                        <strong>{{
                                            selectedPurpose.createdAt
                                        }}</strong>
                                    </b-list-group-item>
                                    <b-list-group-item tag="li">
                                        <label>변경일시</label>
                                        <strong>{{
                                            selectedPurpose.updatedAt
                                        }}</strong>
                                    </b-list-group-item>
                                    <b-list-group-item tag="li">
                                        <label>생성자 ID</label>
                                        <strong>{{
                                            selectedPurpose.createdBy
                                        }}</strong>
                                    </b-list-group-item>
                                    <b-list-group-item tag="li">
                                        <label>수정자 ID</label>
                                        <strong>{{
                                            selectedPurpose.updatedBy
                                        }}</strong>
                                    </b-list-group-item>
                                </b-list-group>

                                <!-- 버튼 영역 -->
                                <div class="btn-area">
                                    <b-button
                                        variant="soft-danger"
                                        @click="deletePurpose"
                                        >삭제</b-button
                                    >
                                    <div class="hstack gap-2">
                                        <b-button
                                            variant="light"
                                            @click="cancelEdit"
                                            >취소</b-button
                                        >
                                        <b-button
                                            variant="dark"
                                            @click="savePurpose"
                                            >저장</b-button
                                        >
                                    </div>
                                </div>
                            </b-col>
                        </div>
                    </section>

                    <!-- 주제영역 설정 -->
                    <section class="target-subject">
                        <div class="target-subject-header">
                            <h4 class="mb-0">주제영역 설정</h4>
                            <p class="text-muted mb-0">
                                <i class="ti ti-info-circle"></i>
                                드래그앤드롭으로 주제영역들의 순서를 조정할 수
                                있습니다.
                            </p>
                            <b-button
                                variant="light-2"
                                class="ms-auto"
                                @click="showSubjectModal = true"
                            >
                                <i class="ti ti-plus"></i> 주제영역 추가
                            </b-button>
                        </div>

                        <!-- ✅ 드래그 가능한 주제영역 테이블 -->
                        <div class="target-subject-table table-responsive">
                            <table
                                class="table table-sm table-hover align-middle"
                            >
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 40px"></th>
                                        <th style="width: 60px">#</th>
                                        <th>주제영역</th>
                                        <th>주제영역 ID</th>
                                        <th>등록일시</th>
                                        <th>변경일시</th>
                                        <th>생성자 ID</th>
                                        <th>수정자 ID</th>
                                    </tr>
                                </thead>

                                <draggable
                                    v-model="subjectAreas"
                                    tag="tbody"
                                    item-key="id"
                                    animation="200"
                                    handle=".drag-handle"
                                >
                                    <template #item="{ element, index }">
                                        <tr class="draggable-row">
                                            <td
                                                class="text-center align-middle"
                                            >
                                                <i
                                                    class="ti ti-grip-vertical drag-handle text-muted"
                                                ></i>
                                            </td>
                                            <td>{{ index + 1 }}</td>
                                            <td>{{ element.name }}</td>
                                            <td>{{ element.id }}</td>
                                            <td>{{ element.createdAt }}</td>
                                            <td>{{ element.updatedAt }}</td>
                                            <td>{{ element.createdBy }}</td>
                                            <td>{{ element.updatedBy }}</td>
                                        </tr>
                                    </template>
                                </draggable>
                            </table>
                        </div>
                    </section>
                </Simplebar>
            </b-card>
        </div>
    </div>

    <!-- Modal: 주제영역 설정 -->
    <TargetSubjectModal
        v-model="showSubjectModal"
        :items="subjectCandidates"
        @save="saveSubjects"
    />
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import PageHeader from '@/components/PageHeader'
import Simplebar from 'simplebar-vue'
import draggable from 'vuedraggable'
import TargetSubjectModal from '@/components/admin/TargetSubjectModal.vue'

/* =============== 상태 관리 =============== */
const purposes = ref([
    {
        id: 'TP001',
        title: '신규회원 타겟',
        desc: '신규가입 후 7일 이내 회원',
        active: true,
        createdAt: '2025-01-03',
        updatedAt: '2025-02-10',
        createdBy: 'admin',
        updatedBy: 'admin'
    },
    {
        id: 'TP002',
        title: '휴면회원 타겟',
        desc: '90일 이상 미접속 회원',
        active: false,
        createdAt: '2025-02-01',
        updatedAt: '2025-03-02',
        createdBy: 'marketer',
        updatedBy: 'marketer'
    }
])

const selectedPurpose = ref(null)
const showSubjectModal = ref(false)

/* =============== 추가 패널(add-box) =============== */
const addOpen = ref(false)
const addButtonVisible = ref(true)

const newPurpose = ref({
    title: '',
    desc: ''
})

/* =============== slide-up Transition (부드러운 열고/닫기) =============== */
const hBeforeEnter = (el) => {
    el.style.height = '0px'
    el.style.overflow = 'hidden'
}

const hEnter = (el) => {
    el.style.transition = 'height .18s ease'
    requestAnimationFrame(() => {
        el.style.height = el.scrollHeight + 'px'
    })
}

/* 닫힐 때: transition 없이 즉시 사라짐 */
const hBeforeLeave = (el) => {
    el.style.height = el.scrollHeight + 'px'
    el.style.overflow = 'hidden'
}

const hLeave = (el) => {
    el.style.transition = 'none' // ← 핵심: 애니메이션 제거
    el.style.height = '0px' // 바로 닫힘
}

/* 닫힌 뒤 추가 버튼 다시 보이기 */
const onAddBoxClosed = () => {
    addButtonVisible.value = true
    updateListHeight()
}

/* =============== add-box 열기 / 닫기 =============== */
const openAddBox = () => {
    addButtonVisible.value = false
    addOpen.value = true
    setTimeout(calcLeftHeight, 50)
}

const closeAddBox = () => {
    addOpen.value = false
}

/* =============== 목적 추가 =============== */
const addPurpose = () => {
    if (!newPurpose.value.title.trim()) {
        alert('목적명을 입력하세요.')
        return
    }

    purposes.value.push({
        id: 'TP' + String(purposes.value.length + 1).padStart(3, '0'),
        title: newPurpose.value.title,
        desc: newPurpose.value.desc,
        active: true,
        createdAt: new Date().toISOString().slice(0, 10),
        updatedAt: new Date().toISOString().slice(0, 10),
        createdBy: 'admin',
        updatedBy: 'admin'
    })

    newPurpose.value = { title: '', desc: '' }
    addOpen.value = false
}

const cancelAdd = () => {
    newPurpose.value = { title: '', desc: '' }
    addOpen.value = false
}

/* =============== 목적 선택 =============== */
const selectPurpose = (p) => {
    selectedPurpose.value = JSON.parse(JSON.stringify(p))
}

/* =============== 목적 수정/삭제 =============== */
const cancelEdit = () => {
    const original = purposes.value.find(
        (p) => p.id === selectedPurpose.value.id
    )
    if (original) {
        selectedPurpose.value = JSON.parse(JSON.stringify(original))
    }
}

const savePurpose = () => {
    const idx = purposes.value.findIndex(
        (p) => p.id === selectedPurpose.value.id
    )
    if (idx > -1) {
        purposes.value[idx] = { ...selectedPurpose.value }
        purposes.value[idx].updatedAt = new Date().toISOString().slice(0, 10)
    }
    alert('저장되었습니다.')
}

const deletePurpose = () => {
    if (!confirm('정말 삭제하시겠습니까?')) return
    purposes.value = purposes.value.filter(
        (p) => p.id !== selectedPurpose.value.id
    )
    selectedPurpose.value = null
}

/* =============== 주제영역 =============== */
const subjectAreas = ref([
    {
        name: '가입정보',
        id: 'SUB001',
        createdAt: '2025-01-01',
        updatedAt: '2025-02-01',
        createdBy: 'admin',
        updatedBy: 'admin'
    },
    {
        name: '결제이력',
        id: 'SUB002',
        createdAt: '2025-01-05',
        updatedAt: '2025-02-03',
        createdBy: 'marketer',
        updatedBy: 'marketer'
    },
    {
        name: '방문기록',
        id: 'SUB003',
        createdAt: '2025-01-10',
        updatedAt: '2025-02-08',
        createdBy: 'data_team',
        updatedBy: 'data_team'
    }
])

const subjectCandidates = ref([
    { no: 1, name: '가입정보', active: true },
    { no: 2, name: '결제이력', active: false },
    { no: 3, name: '방문기록', active: true }
])

const saveSubjects = () => {
    showSubjectModal.value = false
}

/* =============== Simplebar 높이 자동 계산 =============== */
const leftHeight = ref(400)
const rightHeight = ref(0)

// 왼쪽
const calcBaseHeight = () => {
    const baseOffset = 250
    leftHeight.value = window.innerHeight - baseOffset
}

const updateListHeight = () => {
    const baseOffset = 260
    const addOffset = addOpen.value ? 130 : 0
    leftHeight.value = window.innerHeight - (baseOffset + addOffset)
}

watch(addOpen, (val) => {
    if (val === true) {
        // 열릴 때: 문제 없음
        setTimeout(updateListHeight, 10)
    }
})

// 오른쪽
const calcRightHeight = () => {
    const baseOffset = 180
    rightHeight.value = window.innerHeight - baseOffset
}

/* =============== 초기 실행 =============== */
onMounted(() => {
    calcBaseHeight()
    calcRightHeight()

    if (purposes.value.length) selectPurpose(purposes.value[0])
})

window.addEventListener('resize', () => {
    updateListHeight() // ← addOpen 여부에 따라 자동 조절
    calcRightHeight()
})
</script>
