<template>
    <PageHeader
        title="워크북 / 타겟팅 조회"
        parent="타겟팅 관리"
        grandParent="관리자"
    />

    <div class="admin-wrapper workbook-target-wrapper">
        <!-- ==================================================================
             1. 워크북 목록 영역
        ================================================================== -->
        <div class="admin-sidebar workbook-sidebar">
            <b-card
                header-class="admin-sidebar-header"
                :footer-class="{
                    'admin-sidebar-footer': true,
                    'add-open': addWbOpen
                }"
            >
                <!-- =======================
                     워크북 헤더
                ======================== -->
                <template #header>
                    <h5 class="card-title mb-0">
                        워크북 목록
                        <span class="text-info ms-2">
                            {{ filteredWorkbooks.length }}</span
                        >
                    </h5>

                    <!-- search 아이콘 = 필터 아코디언 toggle -->
                    <b-button
                        variant="link"
                        size="sm"
                        class="btn-icon rounded-circle"
                        @click="toggleWbFilter"
                    >
                        <i class="ti ti-filter"></i>
                    </b-button>
                </template>

                <!-- =======================
                         아코디언: 검색/필터/정렬
                    ======================== -->
                <b-collapse v-model="wbFilterOpen" class="filter-box">
                    <!-- 검색 조건 -->
                    <h6 class="text-muted">검색조건</h6>
                    <b-row class="g-1 row-cols-1">
                        <b-col class="hstack gap-2">
                            <label class="col-form-label py-1 col-3"
                                >워크북 ID</label
                            >
                            <b-form-input
                                size="sm"
                                v-model="wbFilter.id"
                                placeholder="예: WB001"
                            />
                        </b-col>

                        <b-col class="hstack gap-2">
                            <label class="col-form-label py-1 col-3"
                                >워크북명</label
                            >
                            <b-form-input size="sm" v-model="wbFilter.name" />
                        </b-col>

                        <b-col class="hstack gap-2">
                            <label class="col-form-label py-1 col-3"
                                >워크북 오너</label
                            >
                            <b-form-input size="sm" v-model="wbFilter.owner" />
                        </b-col>

                        <b-col class="hstack gap-2">
                            <label class="col-form-label py-1 col-3"
                                >워크북 타입</label
                            >

                            <b-button-group size="sm" class="w-100">
                                <!-- 전체 -->
                                <input
                                    type="radio"
                                    class="btn-check"
                                    name="wbTypeRadio"
                                    id="wbTypeAll"
                                    value=""
                                    v-model="wbFilter.type"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 col-4"
                                    for="wbTypeAll"
                                >
                                    전체
                                </label>

                                <!-- 개인워크북 -->
                                <input
                                    type="radio"
                                    class="btn-check"
                                    name="wbTypeRadio"
                                    id="wbTypePersonal"
                                    value="개인워크북"
                                    v-model="wbFilter.type"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 col-4"
                                    for="wbTypePersonal"
                                >
                                    개인워크북
                                </label>

                                <!-- 공용워크북 -->
                                <input
                                    type="radio"
                                    class="btn-check"
                                    name="wbTypeRadio"
                                    id="wbTypePublic"
                                    value="공용워크북"
                                    v-model="wbFilter.type"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 col-4"
                                    for="wbTypePublic"
                                >
                                    공용워크북
                                </label>
                            </b-button-group>
                        </b-col>

                        <b-col class="hstack gap-2">
                            <label class="col-form-label py-1 col-3"
                                >워크북 상태</label
                            >

                            <b-button-group size="sm" class="w-100">
                                <!-- 전체 -->
                                <input
                                    type="radio"
                                    class="btn-check"
                                    name="wbStatusRadio"
                                    id="wbStatusAll"
                                    value=""
                                    v-model="wbFilter.status"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 col-4"
                                    for="wbStatusAll"
                                >
                                    전체
                                </label>

                                <!-- 활성 -->
                                <input
                                    type="radio"
                                    class="btn-check"
                                    name="wbStatusRadio"
                                    id="wbStatusActive"
                                    value="활성"
                                    v-model="wbFilter.status"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 col-4"
                                    for="wbStatusActive"
                                >
                                    활성
                                </label>

                                <!-- 비활성 -->
                                <input
                                    type="radio"
                                    class="btn-check"
                                    name="wbStatusRadio"
                                    id="wbStatusInactive"
                                    value="비활성"
                                    v-model="wbFilter.status"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 col-4"
                                    for="wbStatusInactive"
                                >
                                    비활성
                                </label>
                            </b-button-group>
                        </b-col>
                    </b-row>

                    <hr class="border-dashed" />

                    <!-- 타입 -->
                    <h6 class="text-muted">정렬조건</h6>

                    <b-row class="row-cols-3 g-3">
                        <!-- 1) 가나다순 -->
                        <b-col class="hstack gap-2">
                            <label class="col-form-label text-nowrap"
                                >가나다순</label
                            >

                            <b-button-group size="sm" class="flex-grow-1">
                                <!-- 오름차순 -->
                                <input
                                    class="btn-check"
                                    type="radio"
                                    id="sortNameAsc"
                                    value="asc"
                                    v-model="sortOptions.name.direction"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 btn-icon"
                                    for="sortNameAsc"
                                    id="sortNameAscLabel"
                                    @mouseenter="
                                        showTooltip(
                                            'sortNameAscLabel',
                                            '오름차순'
                                        )
                                    "
                                >
                                    <i class="ti ti-caret-up-filled"></i>
                                </label>

                                <!-- 내림차순 -->
                                <input
                                    class="btn-check"
                                    type="radio"
                                    id="sortNameDesc"
                                    value="desc"
                                    v-model="sortOptions.name.direction"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 btn-icon"
                                    for="sortNameDesc"
                                    id="sortNameDescLabel"
                                    @mouseenter="
                                        showTooltip(
                                            'sortNameDescLabel',
                                            '내림차순'
                                        )
                                    "
                                >
                                    <i class="ti ti-caret-down-filled"></i>
                                </label>
                            </b-button-group>
                        </b-col>

                        <!-- 2) 생성일순 -->
                        <b-col class="hstack gap-2">
                            <label class="col-form-label text-nowrap"
                                >생성일순</label
                            >

                            <b-button-group size="sm" class="flex-grow-1">
                                <input
                                    class="btn-check"
                                    type="radio"
                                    id="sortCreatedAsc"
                                    value="asc"
                                    v-model="sortOptions.created.direction"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 btn-icon"
                                    for="sortCreatedAsc"
                                    id="sortCreatedAscLabel"
                                    @mouseenter="
                                        showTooltip(
                                            'sortCreatedAscLabel',
                                            '오름차순'
                                        )
                                    "
                                >
                                    <i class="ti ti-caret-up-filled"></i>
                                </label>

                                <input
                                    class="btn-check"
                                    type="radio"
                                    id="sortCreatedDesc"
                                    value="desc"
                                    v-model="sortOptions.created.direction"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 btn-icon"
                                    for="sortCreatedDesc"
                                    id="sortCreatedDescLabel"
                                    @mouseenter="
                                        showTooltip(
                                            'sortCreatedDescLabel',
                                            '내림차순'
                                        )
                                    "
                                >
                                    <i class="ti ti-caret-down-filled"></i>
                                </label>
                            </b-button-group>
                        </b-col>

                        <!-- 3) 변경일순 -->
                        <b-col class="hstack gap-2">
                            <label class="col-form-label text-nowrap"
                                >변경일순</label
                            >

                            <b-button-group size="sm" class="flex-grow-1">
                                <input
                                    class="btn-check"
                                    type="radio"
                                    id="sortUpdatedAsc"
                                    value="asc"
                                    v-model="sortOptions.updated.direction"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 btn-icon"
                                    for="sortUpdatedAsc"
                                    id="sortUpdatedAscLabel"
                                    @mouseenter="
                                        showTooltip(
                                            'sortUpdatedAscLabel',
                                            '오름차순'
                                        )
                                    "
                                >
                                    <i class="ti ti-caret-up-filled"></i>
                                </label>

                                <input
                                    class="btn-check"
                                    type="radio"
                                    id="sortUpdatedDesc"
                                    value="desc"
                                    v-model="sortOptions.updated.direction"
                                />
                                <label
                                    class="btn btn-outline-light-2 mb-0 btn-icon"
                                    for="sortUpdatedDesc"
                                    id="sortUpdatedDescLabel"
                                    @mouseenter="
                                        showTooltip(
                                            'sortUpdatedDescLabel',
                                            '내림차순'
                                        )
                                    "
                                >
                                    <i class="ti ti-caret-down-filled"></i>
                                </label>
                            </b-button-group>
                        </b-col>
                    </b-row>

                    <!-- Tooltip 공용 -->
                    <b-tooltip
                        v-if="tooltipTarget"
                        :target="tooltipTarget"
                        placement="bottom"
                    >
                        {{ tooltipText }}
                    </b-tooltip>

                    <hr />

                    <!-- Button -->
                    <div class="hstack gap-2 justify-content-between">
                        <b-button variant="link" @click="resetWbFilter">
                            <i class="ti ti-refresh"></i>초기화
                        </b-button>

                        <div class="hstack gap-2">
                            <!-- 취소 버튼 -->
                            <b-button
                                variant="light"
                                @click="wbFilterOpen = false"
                            >
                                취소
                            </b-button>

                            <!-- 적용 버튼 -->
                            <b-button variant="dark" @click="applyWbFilter">
                                적용
                            </b-button>
                        </div>
                    </div>
                </b-collapse>

                <!-- =======================
                     워크북 목록 Body
                ======================== -->
                <Simplebar
                    :style="{ height: leftHeight + 'px' }"
                    class="workbook-list"
                >
                    <ul class="list-group list-group-flush">
                        <li
                            v-for="wb in filteredWorkbooks"
                            :key="wb.id"
                            class="list-group-item hstack gap-2 cursor-pointer"
                            :class="{
                                active:
                                    detailWorkbook &&
                                    detailWorkbook.wbId === wb.id
                            }"
                            @click="selectWorkbook(wb)"
                        >
                            <i class="ti ti-folder text-primary fs-18"></i>
                            <span class="flex-grow-1">{{ wb.name }}</span>
                            <b-badge pill variant="light">{{
                                wb.count
                            }}</b-badge>
                        </li>
                    </ul>

                    <EmptyMessage v-if="filteredWorkbooks.length === 0">
                        선택된 워크북이 없습니다.
                    </EmptyMessage>
                </Simplebar>

                <!-- footer -->
                <template #footer>
                    <!-- ▼ 추가 버튼 -->
                    <b-button
                        v-show="addButtonVisible"
                        size="lg"
                        variant="link"
                        class="add-btn"
                        @click="openAddBox"
                    >
                        <i class="ti ti-plus"></i> 새 워크북 추가
                    </b-button>

                    <!-- ▼ 추가 입력 패널 -->
                    <transition
                        @before-enter="hBeforeEnter"
                        @enter="hEnter"
                        @before-leave="hBeforeLeave"
                        @leave="hLeave"
                        @after-leave="onAddBoxClosed"
                    >
                        <div v-show="addWbOpen" class="add-list-box">
                            <h5 class="text-primary">새 워크북 추가</h5>
                            <b-row class="g-2 row-cols-1">
                                <b-col class="hstack gap-2">
                                    <label class="col-form-label col-3"
                                        >워크북 타입</label
                                    >
                                    <b-form-select v-model="newWorkbook.type" />
                                </b-col>

                                <b-col class="hstack gap-2">
                                    <label class="col-form-label col-3"
                                        >오너</label
                                    >
                                    <b-form-input v-model="newWorkbook.owner" />
                                </b-col>

                                <b-col class="hstack gap-2">
                                    <label class="col-form-label col-3"
                                        >워크북명</label
                                    >
                                    <b-form-input v-model="newWorkbook.name" />
                                </b-col>
                            </b-row>

                            <div class="btn-area">
                                <b-button variant="light" @click="closeAddBox"
                                    >닫기</b-button
                                >
                                <b-button variant="dark" @click="createWorkbook"
                                    >추가</b-button
                                >
                            </div>
                        </div>
                    </transition>
                </template>
            </b-card>
        </div>

        <!-- ==================================================================
             2. 타겟팅 목록
        ================================================================== -->
        <div class="target-sidebar">
            <b-card header-class="admin-sidebar-header">
                <!-- ======================
                     타겟팅 헤더
                ======================= -->
                <template #header>
                    <h5 class="card-title">
                        타겟팅 목록
                        <span class="text-info">{{
                            filteredTargets.length
                        }}</span>
                    </h5>

                    <div class="hstack gap-1">
                        <!-- 필터 -->
                        <b-button
                            variant="ghost-light"
                            class="btn-icon"
                            @click="tgFilterOpen = !tgFilterOpen"
                        >
                            <i class="ti ti-filter"></i>
                        </b-button>

                        <!-- 체크가 있을 때만 -->
                        <template v-if="checkedTargets.length">
                            <b-button
                                variant="ghost-light"
                                class="btn-icon"
                                @click="bulkMove"
                            >
                                <i class="ti ti-arrow-right"></i>
                            </b-button>
                            <b-button
                                variant="ghost-light"
                                class="btn-icon"
                                @click="bulkCopy"
                            >
                                <i class="ti ti-copy"></i>
                            </b-button>
                            <b-button
                                variant="ghost-light"
                                class="btn-icon"
                                @click="bulkDelete"
                            >
                                <i class="ti ti-trash"></i>
                            </b-button>
                        </template>
                    </div>

                    <!-- 검색 -->
                    <div class="form-search-wrap">
                        <input
                            type="text"
                            v-model="searchTarget"
                            class="form-control"
                            placeholder="타겟팅명 검색"
                        />
                        <b-button
                            variant="link"
                            class="btn-icon search-widget-icon"
                        >
                            <i class="ti ti-search"></i>
                        </b-button>
                    </div>

                    <!-- 타겟팅 필터 아코디언 -->
                    <b-collapse v-model="tgFilterOpen">
                        <div class="border rounded p-3 bg-light-subtle">
                            <div class="row g-2">
                                <div class="col-6">
                                    <label class="form-label"
                                        >타겟팅 타입</label
                                    >
                                    <b-form-select
                                        v-model="tgFilter.type"
                                        :options="tgTypeOptions"
                                    />
                                </div>

                                <div class="col-6">
                                    <label class="form-label"
                                        >삭제 요청여부</label
                                    >
                                    <b-form-select
                                        v-model="tgFilter.deleteRequested"
                                        :options="tgDeleteOptions"
                                    />
                                </div>
                            </div>

                            <div class="text-end mt-3">
                                <b-button
                                    size="sm"
                                    variant="soft-secondary"
                                    @click="resetTgFilter"
                                >
                                    초기화
                                </b-button>
                            </div>
                        </div>
                    </b-collapse>
                </template>

                <!-- ======================
                     타겟팅 목록 Body
                ======================= -->
                <Simplebar
                    :style="{ height: middleHeight + 'px' }"
                    class="target-list"
                >
                    <ul class="list-group list-group-flush">
                        <li
                            v-for="t in filteredTargets"
                            :key="t.id"
                            class="list-group-item hstack gap-2 align-items-center cursor-pointer"
                            :class="{
                                active:
                                    detailTarget && detailTarget.tgId === t.id
                            }"
                            @click="selectTarget(t)"
                        >
                            <b-form-checkbox
                                v-model="checkedTargets"
                                :value="t.id"
                            />

                            <div class="flex-grow-1">
                                <b-badge
                                    v-if="t.deleteRequested"
                                    variant="danger"
                                    class="me-1"
                                    >삭제요청</b-badge
                                >
                                {{ t.name }}
                            </div>

                            <b-button
                                variant="ghost-light"
                                size="sm"
                                class="btn-icon"
                                @click.stop="copyTarget(t)"
                            >
                                <i class="ti ti-copy"></i>
                            </b-button>

                            <b-button
                                variant="ghost-light"
                                size="sm"
                                class="btn-icon"
                                @click.stop="deleteTarget(t)"
                            >
                                <i class="ti ti-trash"></i>
                            </b-button>
                        </li>

                        <EmptyMessage v-if="filteredTargets.length === 0">
                            선택된 워크북이 없습니다.
                        </EmptyMessage>
                    </ul>
                </Simplebar>
            </b-card>
        </div>

        <!-- ==================================================================
             3. 상세정보 (워크북 + 타겟팅 누적 표시)
        ================================================================== -->
        <div class="admin-content workbook-target-detail">
            <b-card>
                <template #header>
                    <h5 class="card-title mb-0">워크북 / 타겟팅 상세정보</h5>
                </template>

                <Simplebar :style="{ height: rightHeight + 'px' }">
                    <!-- ======================
                         워크북 상세정보 전체
                    ======================= -->
                    <div v-if="detailWorkbook" class="mb-4">
                        <h5 class="text-primary mb-3">워크북 상세정보</h5>

                        <FieldView
                            label="워크북 ID"
                            :value="detailWorkbook.wbId"
                        />
                        <FieldView
                            label="워크북 오너"
                            :value="detailWorkbook.owner"
                        />

                        <FieldEditor
                            label="워크북명"
                            fieldKey="wbName"
                            :detail="detailWorkbook"
                            @update="updateWorkbookField"
                        />

                        <FieldView
                            label="등록 일시"
                            :value="detailWorkbook.createdAt"
                        />

                        <FieldEditor
                            label="워크북 타입"
                            fieldKey="wbType"
                            :detail="detailWorkbook"
                            @update="updateWorkbookField"
                        />

                        <FieldView
                            label="변경 일시"
                            :value="detailWorkbook.updatedAt"
                        />

                        <FieldEditor
                            label="워크북 상태"
                            fieldKey="wbStatus"
                            :detail="detailWorkbook"
                            @update="updateWorkbookField"
                        />

                        <FieldView
                            label="생성자 ID"
                            :value="detailWorkbook.creatorId"
                        />

                        <FieldEditor
                            type="number"
                            label="워크북 오더"
                            fieldKey="order"
                            :detail="detailWorkbook"
                            @update="updateWorkbookField"
                        />

                        <FieldView
                            label="수정자 ID"
                            :value="detailWorkbook.modifierId"
                        />
                    </div>

                    <!-- ======================
                         타겟팅 상세정보 전체
                    ======================= -->
                    <div v-if="detailTarget">
                        <h5 class="text-info mb-3">타겟팅 상세정보</h5>

                        <FieldView
                            label="타겟팅 ID"
                            :value="detailTarget.tgId"
                        />

                        <FieldView
                            label="타겟팅 목적"
                            :value="detailTarget.purpose"
                        />

                        <FieldEditor
                            label="타겟팅명"
                            fieldKey="tgName"
                            :detail="detailTarget"
                            @update="updateTargetField"
                        />

                        <FieldView
                            label="주제영역"
                            :value="detailTarget.subject"
                        />

                        <FieldEditor
                            label="타겟팅 타입"
                            fieldKey="tgType"
                            :detail="detailTarget"
                            @update="updateTargetField"
                        />

                        <FieldView
                            label="등록 일시"
                            :value="detailTarget.createdAt"
                        />

                        <FieldEditor
                            type="number"
                            label="제한건수"
                            fieldKey="limit"
                            :detail="detailTarget"
                            @update="updateTargetField"
                        />

                        <FieldView
                            label="변경 일시"
                            :value="detailTarget.updatedAt"
                        />

                        <FieldEditor
                            label="삭제 요청일"
                            fieldKey="deleteDate"
                            :detail="detailTarget"
                            @update="updateTargetField"
                        />

                        <FieldView
                            label="생성자 ID"
                            :value="detailTarget.creatorId"
                        />

                        <FieldEditor
                            label="워크북 ID"
                            fieldKey="wbId"
                            :detail="detailTarget"
                            @update="updateTargetField"
                        />

                        <FieldView
                            label="수정자 ID"
                            :value="detailTarget.modifierId"
                        />
                    </div>

                    <EmptyMessage v-if="!detailWorkbook && !detailTarget">
                        선택된 워크북/타겟팅이 없습니다.
                    </EmptyMessage>
                </Simplebar>
            </b-card>
        </div>
    </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import Simplebar from 'simplebar-vue'
import Swal from 'sweetalert2'
import PageHeader from '@/components/PageHeader.vue'
import EmptyMessage from '@/components/EmptyMessage.vue'
import FieldView from '@/components/admin/system/FieldView.vue'
import FieldEditor from '@/components/admin/system/FieldEditor.vue'

/* -------------------------
   더미 데이터 유지
-------------------------- */
const workbookList = ref([
    {
        id: 'WB001',
        name: '광고 캠페인',
        count: 2,
        owner: '91313045',
        type: '개인워크북',
        status: '활성',
        createdAt: '2025-01-01',
        updatedAt: '2025-01-05',
        wbType: '일반',
        wbStatus: '정상',
        order: 1,
        creatorId: 'admin',
        modifierId: 'manager'
    },
    {
        id: 'WB002',
        name: 'VIP 분석',
        count: 3,
        owner: '91313045',
        type: '공용워크북',
        status: '비활성',
        createdAt: '2025-01-02',
        updatedAt: '2025-01-03',
        wbType: '일반',
        wbStatus: '정상',
        order: 2,
        creatorId: 'admin',
        modifierId: 'manager'
    }
])

const targetList = ref([
    {
        id: 'TGT1001',
        wbId: 'WB001',
        name: 'VIP 추출',
        deleteRequested: false,
        type: '세그먼트',
        purpose: '캠페인 대상 선정',
        subject: '고객 분석',
        tgType: '세그먼트',
        limit: 10000,
        createdAt: '2025-01-01',
        updatedAt: '2025-01-05',
        deleteDate: '',
        creatorId: 'admin',
        modifierId: 'manager'
    },
    {
        id: 'TGT1002',
        wbId: 'WB001',
        name: '신규 고객 군',
        deleteRequested: true,
        type: '세그먼트',
        purpose: '캠페인 대상 선정',
        subject: '고객 분석',
        tgType: '세그먼트',
        limit: 8000,
        createdAt: '2025-01-01',
        updatedAt: '2025-01-04',
        deleteDate: '2025-01-03',
        creatorId: 'admin',
        modifierId: 'manager'
    }
])

/* -------------------------
   워크북 필터 + 정렬
-------------------------- */
const wbFilterOpen = ref(false)

const wbFilter = ref({
    id: '',
    name: '',
    owner: '',
    type: '',
    status: ''
})

const resetWbFilter = () => {
    wbFilter.value = { id: '', name: '', owner: '', type: '', status: '' }
}

const sortOptions = ref({
    name: { enabled: false, direction: 'asc' },
    created: { enabled: false, direction: 'asc' },
    updated: { enabled: false, direction: 'asc' }
})

const tooltipTarget = ref(null)
const tooltipText = ref('')
const showTooltip = (targetId, text) => {
    tooltipTarget.value = targetId
    tooltipText.value = text
}

const filteredWorkbooks = computed(() => {
    let list = [...workbookList.value]

    list = list
        .filter((w) =>
            wbFilter.value.id ? w.id.includes(wbFilter.value.id) : true
        )
        .filter((w) =>
            wbFilter.value.name ? w.name.includes(wbFilter.value.name) : true
        )
        .filter((w) =>
            wbFilter.value.owner ? w.owner.includes(wbFilter.value.owner) : true
        )
        .filter((w) =>
            wbFilter.value.type ? w.type === wbFilter.value.type : true
        )
        .filter((w) =>
            wbFilter.value.status ? w.status === wbFilter.value.status : true
        )

    const sorts = []

    if (sortOptions.value.name.enabled) {
        sorts.push((a, b) =>
            sortOptions.value.name.direction === 'asc'
                ? a.name.localeCompare(b.name)
                : b.name.localeCompare(a.name)
        )
    }
    if (sortOptions.value.created.enabled) {
        sorts.push((a, b) =>
            sortOptions.value.created.direction === 'asc'
                ? a.createdAt.localeCompare(b.createdAt)
                : b.createdAt.localeCompare(a.createdAt)
        )
    }
    if (sortOptions.value.updated.enabled) {
        sorts.push((a, b) =>
            sortOptions.value.updated.direction === 'asc'
                ? a.updatedAt.localeCompare(b.updatedAt)
                : b.updatedAt.localeCompare(a.updatedAt)
        )
    }

    list.sort((a, b) => {
        for (const fn of sorts) {
            const r = fn(a, b)
            if (r !== 0) return r
        }
        return 0
    })

    return list
})

/* -------------------------
   add-box (워크북 추가)
-------------------------- */
const addWbOpen = ref(false)
const addButtonVisible = ref(true)

const newWorkbook = ref({
    type: '개인워크북',
    owner: '',
    name: ''
})

/* ★★★ 최소 Transition 코드 — 깔끔하고 부드러움 ★★★ */
const hBeforeEnter = (el) => {
    el.style.height = '0px'
    el.style.overflow = 'hidden'
}

const hEnter = (el) => {
    el.style.transition = 'height .18s ease'
    requestAnimationFrame(() => {
        el.style.height = el.scrollHeight + 'px'
    })
}

const hBeforeLeave = (el) => {
    el.style.height = el.scrollHeight + 'px'
    el.style.overflow = 'hidden'
}

const hLeave = (el) => {
    el.style.transition = 'height .18s ease'
    requestAnimationFrame(() => {
        el.style.height = '0px'
    })
}

/* add-box Open */
const openAddBox = () => {
    wbFilterOpen.value = false // 🔥 필터 닫기 추가

    addButtonVisible.value = false
    addWbOpen.value = true
    setTimeout(updateListHeight, 50)
}

const toggleWbFilter = () => {
    wbFilterOpen.value = !wbFilterOpen.value

    if (wbFilterOpen.value) {
        // ⭐ 필터 열릴 때 add-box 닫기
        addWbOpen.value = false
        addButtonVisible.value = true
        updateListHeight()
    }
}

/* add-box Close */
const closeAddBox = () => {
    addWbOpen.value = false
}

/* transition 종료 후 자연스럽게 버튼 복귀 */
const onAddBoxClosed = () => {
    addButtonVisible.value = true
    updateListHeight()
}

/* -------------------------
   높이 계산
-------------------------- */
const leftHeight = ref(400)
const middleHeight = ref(400)
const rightHeight = ref(500)

const calcBaseHeight = () => {
    const baseOffset = wbFilterOpen.value ? 616 : 260
    leftHeight.value = window.innerHeight - baseOffset
    middleHeight.value = window.innerHeight - baseOffset
    rightHeight.value = window.innerHeight - baseOffset - 40
}

const updateListHeight = () => {
    const addOffset = addWbOpen.value ? 160 : 0
    const baseOffset = wbFilterOpen.value ? 616 : 260
    leftHeight.value = window.innerHeight - (baseOffset + addOffset)
}

/* -------------------------
   워크북 추가 실행
-------------------------- */
const createWorkbook = () => {
    if (!newWorkbook.value.name) {
        Swal.fire('워크북명을 입력하세요!', '', 'warning')
        return
    }

    const newId = 'WB' + Date.now().toString().slice(-4)

    workbookList.value.push({
        id: newId,
        name: newWorkbook.value.name,
        owner: newWorkbook.value.owner || '관리자',
        type: newWorkbook.value.type,
        count: 0,
        status: '활성',
        createdAt: new Date().toISOString().slice(0, 10),
        updatedAt: new Date().toISOString().slice(0, 10),
        wbType: newWorkbook.value.type,
        wbStatus: '정상'
    })

    newWorkbook.value = { type: '개인워크북', owner: '', name: '' }
    addWbOpen.value = false
}

/* -------------------------
   타겟팅 필터
-------------------------- */
const tgFilterOpen = ref(false)
const searchTarget = ref('')
const tgFilter = ref({ type: '', deleteRequested: '' })

const resetTgFilter = () => {
    tgFilter.value = { type: '', deleteRequested: '' }
}

/* -------------------------
   상세 정보
-------------------------- */
const detailWorkbook = ref(null)
const detailTarget = ref(null)
const selectedWorkbookId = ref(null)

const targetListForWorkbook = computed(() =>
    targetList.value.filter((t) => t.wbId === selectedWorkbookId.value)
)

const filteredTargets = computed(() =>
    targetListForWorkbook.value
        .filter((t) =>
            t.name.toLowerCase().includes(searchTarget.value.toLowerCase())
        )
        .filter((t) =>
            tgFilter.value.type ? t.tgType === tgFilter.value.type : true
        )
        .filter((t) =>
            tgFilter.value.deleteRequested !== ''
                ? t.deleteRequested === tgFilter.value.deleteRequested
                : true
        )
)

/* 선택 처리 */
const selectWorkbook = (w) => {
    selectedWorkbookId.value = w.id

    detailWorkbook.value = {
        wbId: w.id,
        wbName: w.name,
        owner: w.owner,
        wbType: w.wbType ?? '일반',
        wbStatus: w.wbStatus ?? w.status ?? '정상',
        createdAt: w.createdAt ?? '',
        updatedAt: w.updatedAt ?? '',
        order: w.order ?? 1,
        creatorId: w.creatorId ?? '',
        modifierId: w.modifierId ?? ''
    }

    detailTarget.value = null
}

const selectTarget = (t) => {
    detailTarget.value = {
        tgId: t.id,
        tgName: t.name,
        wbId: t.wbId,
        purpose: t.purpose ?? '',
        subject: t.subject ?? '',
        tgType: t.tgType ?? t.type ?? '',
        limit: t.limit ?? 0,
        createdAt: t.createdAt ?? '',
        updatedAt: t.updatedAt ?? '',
        deleteDate: t.deleteDate ?? (t.deleteRequested ? '---' : ''),
        creatorId: t.creatorId ?? '',
        modifierId: t.modifierId ?? ''
    }
}

/* -------------------------
   타겟 일괄 처리
-------------------------- */
const checkedTargets = ref([])

const copyTarget = (t) => {
    const newId = 'TGT' + Date.now()
    targetList.value.push({
        ...t,
        id: newId,
        name: `${t.name} (복사)`
    })
}

const deleteTarget = (t) => {
    Swal.fire({
        title: '삭제하시겠습니까?',
        html: `<b>${t.name}</b> 타겟팅은 되돌릴 수 없습니다.`,
        icon: 'warning',
        showCancelButton: true
    }).then((res) => {
        if (res.isConfirmed) {
            targetList.value = targetList.value.filter((v) => v.id !== t.id)
            if (detailTarget.value?.tgId === t.id) detailTarget.value = null
        }
    })
}

const bulkCopy = () => {
    checkedTargets.value.forEach((id) => {
        const t = targetList.value.find((x) => x.id === id)
        if (t) copyTarget(t)
    })
}

const bulkDelete = () => {
    Swal.fire({
        title: `${checkedTargets.value.length}개 삭제`,
        icon: 'warning',
        showCancelButton: true
    }).then((res) => {
        if (res.isConfirmed) {
            targetList.value = targetList.value.filter(
                (t) => !checkedTargets.value.includes(t.id)
            )
            checkedTargets.value = []
            detailTarget.value = null
        }
    })
}

const bulkMove = () => {
    Swal.fire('준비중', '워크북 이동 기능을 모달로 연동하세요.', 'info')
}

/* -------------------------
   높이 계산 등록
-------------------------- */
onMounted(() => {
    calcBaseHeight()
    window.addEventListener('resize', calcBaseHeight)

    watch(wbFilterOpen, () => setTimeout(calcBaseHeight, 10))
    watch(tgFilterOpen, () => setTimeout(calcBaseHeight, 10))
})
</script>
