<template>
    <b-modal
        v-model="visible"
        title="메시지 템플릿 조회"
        size="xxl"
        centered
        scrollable
        teleport-to="body"
        class="message-select-wrapper"
    >
        <b-row class="g-1 row-cols-1 row-cols-xl-2">
            <!-- 메시지 리스트 -->
            <b-col xl="8">
                <b-card
                    class="message-list"
                    :class="{ 'personalization-active': showPersonalization }"
                >
                    <template v-if="!showPersonalization" #header>
                        <transition name="slide-fade" appear>
                            <div>
                                <b-row class="g-2 align-items-end">
                                    <b-col cols="auto">
                                        <label class="form-label"
                                            >저장경로</label
                                        >
                                        <b-form-select
                                            v-model="search.path"
                                            :options="options.path"
                                        />
                                    </b-col>

                                    <b-col cols="auto">
                                        <label class="form-label"
                                            >주제영역</label
                                        >
                                        <b-form-select
                                            v-model="search.topic"
                                            :options="options.topic"
                                        />
                                    </b-col>

                                    <b-col cols="auto">
                                        <label class="form-label"
                                            >타겟팅명 / ID</label
                                        >
                                        <div class="input-group">
                                            <b-form-select
                                                v-model="search.targetType"
                                                :options="options.targetType"
                                                class="w-auto"
                                            />
                                            <b-form-input
                                                v-model="search.targetName"
                                                placeholder="검색어 입력"
                                                class="w-auto"
                                            />
                                        </div>
                                    </b-col>

                                    <b-col cols="auto">
                                        <label class="form-label">등록자</label>
                                        <b-form-input
                                            v-model="search.regUser"
                                            placeholder="등록자 이름"
                                        />
                                    </b-col>

                                    <b-col cols="auto" class="text-end mt-2">
                                        <b-button
                                            variant="dark"
                                            @click="onSearch"
                                        >
                                            <i class="ti ti-search"></i> 검색
                                        </b-button>
                                    </b-col>
                                </b-row>
                            </div>
                        </transition>
                    </template>

                    <!-- 개인화 내용 -->
                    <transition name="fade-slide" mode="out-in">
                        <div v-if="!showPersonalization" key="table">
                            <Simplebar>
                                <b-table
                                    hover
                                    small
                                    responsive
                                    head-variant="light"
                                    :fields="fields"
                                    :items="templates"
                                    selectable
                                    select-mode="single"
                                    @row-clicked="onRowSelect"
                                    class="text-center align-middle"
                                >
                                    <template #cell(no)="data">{{
                                        data.index + 1
                                    }}</template>
                                    <template #cell(selectable)="data">
                                        <b-badge
                                            :variant="
                                                data.item.isSelectable
                                                    ? 'info-subtle'
                                                    : 'danger-subtle'
                                            "
                                            :class="
                                                data.item.isSelectable
                                                    ? 'bg-info-subtle text-info'
                                                    : 'bg-danger-subtle text-danger'
                                            "
                                        >
                                            {{
                                                data.item.isSelectable
                                                    ? '가능'
                                                    : '불가'
                                            }}
                                        </b-badge>
                                    </template>
                                    <template #cell(msgName)="data">
                                        <span
                                            :class="[
                                                selectedRow?.msgId ===
                                                data.item.msgId
                                                    ? 'text-primary'
                                                    : ''
                                            ]"
                                        >
                                            {{ data.item.msgName }}
                                        </span>
                                    </template>
                                </b-table>
                            </Simplebar>
                            <Pager
                                :page="page"
                                :total="total"
                                @update:page="page = $event"
                            />
                        </div>

                        <div
                            v-else
                            key="personalization"
                            class="personalization-section"
                        >
                            <div class="header mb-3">
                                <b-button
                                    variant="link"
                                    @click="showPersonalization = false"
                                    class="my-n1 p-0"
                                >
                                    <i class="ti ti-arrow-left"></i> 목록으로
                                </b-button>
                                <div class="vr mx-2"></div>
                                <h4 class="mb-0 fs-16">개인화 항목 설정</h4>
                            </div>

                            <div class="dual-listbox">
                                <div class="dual-listbox-container">
                                    <!-- 선택 가능한 항목 -->
                                    <div class="dual-listbox-left">
                                        <h6 class="mb-2">
                                            선택 가능한 항목
                                            <span class="text-info ms-1">{{
                                                personalizationCandidates.length
                                            }}</span
                                            >개
                                        </h6>
                                        <Simplebar
                                            class="personalization-scroll"
                                        >
                                            <draggable
                                                v-model="
                                                    personalizationCandidates
                                                "
                                                item-key="key"
                                                group="pGroup"
                                                animation="180"
                                                class="list-group list-group-sm"
                                            >
                                                <template
                                                    #item="{ element, index }"
                                                >
                                                    <div
                                                        class="list-group-item selectable-item hstack gap-2 justify-content-between"
                                                        :class="{
                                                            active: selectedCandidateKeys.includes(
                                                                element.key
                                                            )
                                                        }"
                                                        @click="
                                                            toggleCandidateSelection(
                                                                element.key
                                                            )
                                                        "
                                                    >
                                                        <div>
                                                            <span class="me-1"
                                                                >{{
                                                                    index + 1
                                                                }}.</span
                                                            >
                                                            {{ element.text }}
                                                        </div>

                                                        <div
                                                            class="hstack me-n2"
                                                        >
                                                            <b-button
                                                                size="sm"
                                                                variant="link"
                                                                class="btn-icon"
                                                                :id="`copy-btn-${element.key}`"
                                                                @click.stop="
                                                                    copyToClipboard(
                                                                        element.key
                                                                    )
                                                                "
                                                            >
                                                                <i
                                                                    class="ti ti-copy"
                                                                ></i>
                                                            </b-button>
                                                            <b-tooltip
                                                                :target="`copy-btn-${element.key}`"
                                                                placement="top"
                                                            >
                                                                복사하기
                                                            </b-tooltip>
                                                            <b-button
                                                                size="sm"
                                                                variant="link"
                                                                class="btn-icon"
                                                                :id="`delete-btn-${element.key}`"
                                                                @click.stop="
                                                                    removeCandidate(
                                                                        element
                                                                    )
                                                                "
                                                            >
                                                                <i
                                                                    class="ti ti-trash"
                                                                ></i>
                                                            </b-button>
                                                            <b-tooltip
                                                                :target="`delete-btn-${element.key}`"
                                                                placement="top"
                                                            >
                                                                삭제하기
                                                            </b-tooltip>
                                                        </div>
                                                    </div>
                                                </template>
                                            </draggable>
                                        </Simplebar>
                                    </div>

                                    <!-- 이동 버튼 -->
                                    <div class="dual-listbox-controls">
                                        <!-- 선택 이동 -->
                                        <b-button
                                            variant="light-2"
                                            class="btn-icon rounded-circle"
                                            @click="moveSelectedRight"
                                        >
                                            <i class="ti ti-chevron-right"></i>
                                        </b-button>

                                        <!-- 전체 이동 -->
                                        <b-button
                                            variant="light-2"
                                            class="btn-icon rounded-circle"
                                            @click="moveAllRight"
                                        >
                                            <i class="ti ti-chevrons-right"></i>
                                        </b-button>

                                        <!-- 전체 취소 -->
                                        <b-button
                                            variant="light-2"
                                            class="btn-icon rounded-circle"
                                            @click="moveAllLeft"
                                        >
                                            <i class="ti ti-chevrons-left"></i>
                                        </b-button>

                                        <!-- 선택 취소 -->
                                        <b-button
                                            variant="light-2"
                                            class="btn-icon rounded-circle"
                                            @click="moveSelectedLeft"
                                        >
                                            <i class="ti ti-chevron-left"></i>
                                        </b-button>
                                    </div>

                                    <!-- 선택된 개인화 항목 -->
                                    <div class="dual-listbox-right">
                                        <h6 class="mb-2">
                                            선택된 개인화 항목
                                            <span class="text-info ms-1">{{
                                                selectedPersonalizationList.length
                                            }}</span
                                            >개
                                        </h6>
                                        <Simplebar
                                            class="personalization-scroll"
                                        >
                                            <draggable
                                                v-model="
                                                    selectedPersonalizationList
                                                "
                                                item-key="key"
                                                group="pGroup"
                                                animation="180"
                                                class="list-group"
                                            >
                                                <template
                                                    #item="{ element, index }"
                                                >
                                                    <div
                                                        class="list-group-item selectable-item hstack gap-2 justify-content-between"
                                                        :class="{
                                                            active: selectedSelectedKeys.includes(
                                                                element.key
                                                            )
                                                        }"
                                                        @click="
                                                            toggleSelectedSelection(
                                                                element.key
                                                            )
                                                        "
                                                    >
                                                        <div>
                                                            <span class="me-1"
                                                                >{{
                                                                    index + 1
                                                                }}.</span
                                                            >
                                                            {{ element.text }}
                                                        </div>
                                                    </div>
                                                </template>
                                            </draggable>
                                        </Simplebar>
                                        <div class="fs-12 text-danger mt-2">
                                            <i class="ti ti-alert-circle"></i>
                                            개인화 적용 후 저장 가능합니다
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </transition>
                </b-card>
            </b-col>

            <!-- 메시지 미리보기 -->
            <b-col xl="4">
                <b-card class="preview-pane">
                    <template #header>
                        <h4 class="card-title mb-0">메시지 미리보기</h4>
                    </template>

                    <div v-if="selectedRow" class="h-100 d-flex flex-column">
                        <h6 class="fw-semibold mb-2">
                            {{ selectedRow.msgName }}
                        </h6>
                        <ul class="message-info list-unstyled">
                            <li>
                                ID: <strong>{{ selectedRow.msgId }}</strong>
                            </li>
                            <li>
                                타입: <strong>{{ selectedRow.msgType }}</strong>
                            </li>
                            <li>
                                등록자:
                                <strong>{{ selectedRow.planner }}</strong>
                            </li>
                            <li>
                                등록일:
                                <strong>{{ selectedRow.createdAt }}</strong>
                            </li>
                        </ul>

                        <Simplebar class="message-preview mb-3">
                            <div v-html="previewWithPersonalization"></div>
                        </Simplebar>
                    </div>

                    <EmptyMessage v-else
                        >선택된 메시지가 없습니다.</EmptyMessage
                    >

                    <!-- footer 슬롯: 개인화가 필요한 경우만 표시 -->
                    <template #footer>
                        <transition name="fade">
                            <div
                                v-if="selectedRow?.requiresPersonalization"
                                class="hstack gap-2 justify-content-center"
                            >
                                <b-button variant="light" size="sm"
                                    >메시지 원문</b-button
                                >
                                <b-button variant="soft-info" size="sm"
                                    >개인화 항목 매핑</b-button
                                >
                                <b-button variant="soft-danger" size="sm"
                                    >개인화 데이터 매핑</b-button
                                >
                            </div>
                        </transition>
                    </template>
                </b-card>
            </b-col>
        </b-row>

        <!-- footer -->
        <template #footer>
            <span class="me-auto text-info">
                <i class="ti ti-alert-circle"></i> 메시지명이 동일한 경우는
                메시지ID로 확인하세요.</span
            >
            <b-button variant="light" @click="close">취소</b-button>
            <b-button
                variant="primary"
                @click="submit"
                :disabled="
                    selectedRow?.requiresPersonalization &&
                    selectedPersonalizations.length === 0
                "
            >
                적용
            </b-button>
        </template>
    </b-modal>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import Simplebar from 'simplebar-vue'
import Pager from '@/components/Pager.vue'
import EmptyMessage from '@/components/EmptyMessage.vue'
import draggable from 'vuedraggable'

onMounted(() => {
    if (templates.value.length > 0) {
        onRowSelect(templates.value[0]) // 첫 번째 메시지 자동 선택
    }
})

const props = defineProps({ modelValue: Boolean })
const emit = defineEmits(['update:modelValue', 'submit'])

const visible = computed({
    get: () => props.modelValue,
    set: (v) => emit('update:modelValue', v)
})

// 페이지 상태
const page = ref(1)
const total = ref(20)

// 검색 필터
const search = ref({
    path: '',
    topic: '',
    targetType: '',
    targetName: '',
    regUser: ''
})
const options = {
    path: ['전체', '공유폴더', '개인폴더'],
    topic: ['전체', '상품', '이벤트', '혜택'],
    targetType: ['전체', '타겟팅명', '타겟팅ID']
}

// 필드
const fields = [
    { key: 'no', label: 'No', thStyle: { width: '50px' } },
    { key: 'selectable', label: '선택', thStyle: { width: '50px' } },
    { key: 'msgName', label: '메시지명' },
    { key: 'msgId', label: '메시지ID' },
    { key: 'planner', label: '등록자' },
    { key: 'permissionType', label: '퍼미션타입' },
    { key: 'businessType', label: '업무타입' },
    { key: 'approvalStatus', label: '승인여부' },
    { key: 'msgType', label: '메시지타입' },
    { key: 'sendDate', label: '발송일자' },
    { key: 'fromNumber', label: '발신번호' },
    { key: 'toNumber', label: '수신번호' }
]

// 더미 데이터
const templates = ref([
    {
        msgId: 'MSG001',
        msgName: '신규가입 웰컴 메시지',
        planner: '홍길동',
        permissionType: 'OPT-IN',
        businessType: '회원관리',
        approvalStatus: '승인',
        msgType: 'LMS',
        sendDate: '2025-10-10',
        fromNumber: '02-1234-5678',
        toNumber: '010-1111-2222',
        isSelectable: true,
        requiresPersonalization: true, // ← 테스트 위해 true로 변경
        preview: `<p>[{{userName}}] 회원가입을 환영합니다.<br>첫 주문 시 10% 쿠폰 증정 🎉</p>`,

        // ✔ MSG001 개인화 변수 샘플 3개 추가
        variables: [
            { key: 'userName', label: '고객명' },
            { key: 'joinDate', label: '가입일' },
            { key: 'welcomeCoupon', label: '웰컴쿠폰' }
        ]
    },

    {
        msgId: 'MSG002',
        msgName: '생일 축하 메시지',
        planner: '김하늘',
        permissionType: 'OPT-IN',
        businessType: '프로모션',
        approvalStatus: '검토중',
        msgType: 'SMS',
        sendDate: '2025-10-09',
        fromNumber: '02-9876-5432',
        toNumber: '010-3333-4444',
        isSelectable: false,
        requiresPersonalization: true,
        preview: `<p>{{userName}}님, 생일을 축하드립니다 🎂<br>쿠폰코드: {{couponCode}}<br>잔여포인트: {{point}}</p>`,

        // ✔ MSG002 개인화 변수 샘플 4개 제공
        variables: [
            { key: 'userName', label: '고객명' },
            { key: 'couponCode', label: '쿠폰코드' },
            { key: 'birthDate', label: '생일' },
            { key: 'point', label: '보유포인트' }
        ]
    }
])

// 선택된 메시지
const selectedRow = ref(null)
const showPersonalization = ref(false)

// 개인화 항목 선택
const selectedCandidates = ref([])
const selectedPersonalizations = ref([])

// row 선택 시 동작
function onRowSelect(item) {
    selectedRow.value = item
    selectedPersonalizations.value = []
    selectedCandidates.value = []
    showPersonalization.value = item.requiresPersonalization
}

// variables → selectBox에 표시할 옵션
const availablePersonalizations = computed(() => {
    return (
        selectedRow.value?.variables?.map((v) => ({
            value: v.key,
            text: v.label
        })) || []
    )
})

// preview에 선택된 항목 강조
const previewWithPersonalization = computed(() => {
    if (!selectedRow.value) return ''
    let html = selectedRow.value.preview

    selectedPersonalizations.value.forEach((k) => {
        html = html.replaceAll(
            `{{${k}}}`,
            `<span class='text-primary fw-bold'>{{${k}}}</span>`
        )
    })

    return html
})

// footer 기능
function close() {
    visible.value = false
}

function submit() {
    emit('submit', {
        template: selectedRow.value,
        personalization: selectedPersonalizations.value
    })
    close()
}

function onSearch() {
    console.log('검색 실행:', search.value)
}

/* -----------------------------
   개인화 드래그 리스트 상태
------------------------------ */
const personalizationCandidates = ref([])
const selectedPersonalizationList = ref([])

/* 선택 상태 저장 */
const selectedCandidateKeys = ref([])
const selectedSelectedKeys = ref([])

/* 메시지 선택 시 초기화 */
watch(selectedRow, (row) => {
    if (!row) return

    personalizationCandidates.value =
        row.variables?.map((v) => ({ key: v.key, text: v.label })) || []

    selectedPersonalizationList.value = []
    selectedCandidateKeys.value = []
    selectedSelectedKeys.value = []
})

/* 항목 선택 토글 */
function toggleCandidateSelection(key) {
    selectedCandidateKeys.value.includes(key)
        ? (selectedCandidateKeys.value = selectedCandidateKeys.value.filter(
              (k) => k !== key
          ))
        : selectedCandidateKeys.value.push(key)
}

function toggleSelectedSelection(key) {
    selectedSelectedKeys.value.includes(key)
        ? (selectedSelectedKeys.value = selectedSelectedKeys.value.filter(
              (k) => k !== key
          ))
        : selectedSelectedKeys.value.push(key)
}

/* 복사 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert(`'${text}' 복사되었습니다.`)
    })
}

/* 삭제 */
function removeCandidate(item) {
    personalizationCandidates.value = personalizationCandidates.value.filter(
        (i) => i.key !== item.key
    )

    selectedCandidateKeys.value = selectedCandidateKeys.value.filter(
        (k) => k !== item.key
    )
}

function removeSelected(item) {
    selectedPersonalizationList.value =
        selectedPersonalizationList.value.filter((i) => i.key !== item.key)

    selectedSelectedKeys.value = selectedSelectedKeys.value.filter(
        (k) => k !== item.key
    )
}

/* 이동 기능 */
function moveSelectedRight() {
    const moveItems = personalizationCandidates.value.filter((i) =>
        selectedCandidateKeys.value.includes(i.key)
    )

    selectedPersonalizationList.value.push(...moveItems)

    personalizationCandidates.value = personalizationCandidates.value.filter(
        (i) => !selectedCandidateKeys.value.includes(i.key)
    )

    selectedCandidateKeys.value = []
}

function moveSelectedLeft() {
    const moveItems = selectedPersonalizationList.value.filter((i) =>
        selectedSelectedKeys.value.includes(i.key)
    )

    personalizationCandidates.value.push(...moveItems)

    selectedPersonalizationList.value =
        selectedPersonalizationList.value.filter(
            (i) => !selectedSelectedKeys.value.includes(i.key)
        )

    selectedSelectedKeys.value = []
}

function moveAllRight() {
    selectedPersonalizationList.value.push(...personalizationCandidates.value)
    personalizationCandidates.value = []
    selectedCandidateKeys.value = []
}

function moveAllLeft() {
    personalizationCandidates.value.push(...selectedPersonalizationList.value)
    selectedPersonalizationList.value = []
    selectedSelectedKeys.value = []
}
</script>
